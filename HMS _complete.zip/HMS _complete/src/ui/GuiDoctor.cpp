#if HMS_HAS_SFML && HMS_HAS_IMGUI
#include "ui/App.h"
#include <imgui.h>
#include <string>

static std::string s_dMsg;

void renderDoctorPanel(App& app) {
    auto& dash = app.doctorDashboard();

    ImGui::TextColored({0.4f,0.7f,1.f,1.f}, "Doctor Dashboard");
    ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
    if (ImGui::Button("Logout", {80, 0})) { app.logout(); return; }
    ImGui::Separator();
    if (!s_dMsg.empty()) { ImGui::TextColored({0.2f,0.9f,0.4f,1.f}, "%s", s_dMsg.c_str()); }

    if (!ImGui::BeginTabBar("##docTabs")) return;

    // ── My Appointments ──
    if (ImGui::BeginTabItem("My Appointments")) {
        auto appts = dash.myAppointments(true);
        if (ImGui::BeginTable("##dAppts", 6, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY)) {
            ImGui::TableSetupColumn("ID"); ImGui::TableSetupColumn("Patient");
            ImGui::TableSetupColumn("DateTime"); ImGui::TableSetupColumn("Status");
            ImGui::TableSetupColumn("Notes"); ImGui::TableSetupColumn("Actions", ImGuiTableColumnFlags_WidthFixed, 180);
            ImGui::TableHeadersRow();
            for (auto& a : appts) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(a.getId().c_str());
                ImGui::TableSetColumnIndex(1); ImGui::TextUnformatted(a.getPatientId().c_str());
                ImGui::TableSetColumnIndex(2); ImGui::TextUnformatted(a.getDateTime().c_str());
                ImGui::TableSetColumnIndex(3); ImGui::TextUnformatted(toString(a.getStatus()).c_str());
                ImGui::TableSetColumnIndex(4); ImGui::TextUnformatted(a.getNotes().c_str());
                ImGui::TableSetColumnIndex(5);
                ImGui::PushID(a.getId().c_str());
                auto st = a.getStatus();
                if (st == AppointmentStatus::Pending) {
                    if (ImGui::SmallButton("Accept")) { dash.acceptAppointment(a.getId()); s_dMsg="Accepted."; }
                    ImGui::SameLine();
                }
                if (st == AppointmentStatus::Pending || st == AppointmentStatus::Accepted) {
                    if (ImGui::SmallButton("Cancel")) { dash.cancelAppointment(a.getId()); s_dMsg="Cancelled."; }
                    ImGui::SameLine();
                }
                if (st == AppointmentStatus::Accepted) {
                    if (ImGui::SmallButton("Complete")) { dash.completeAppointment(a.getId()); s_dMsg="Completed."; }
                }
                ImGui::PopID();
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Patients ──
    if (ImGui::BeginTabItem("Patients")) {
        static char s_dPatSearch[128] = "";
        ImGui::SetNextItemWidth(200);
        ImGui::InputText("Search##dp", s_dPatSearch, sizeof(s_dPatSearch));
        auto pats = dash.searchMyPatients(s_dPatSearch);
        if (ImGui::BeginTable("##dPats", 3, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg)) {
            ImGui::TableSetupColumn("ID"); ImGui::TableSetupColumn("Name"); ImGui::TableSetupColumn("Email");
            ImGui::TableHeadersRow();
            for (auto* p : pats) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(p->getId().c_str());
                ImGui::TableSetColumnIndex(1); ImGui::TextUnformatted(p->getName().c_str());
                ImGui::TableSetColumnIndex(2); ImGui::TextUnformatted(p->getEmail().c_str());
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Profile ──
    if (ImGui::BeginTabItem("Profile")) {
        auto prof = dash.myProfile();
        if (prof) {
            ImGui::Text("ID: %s", prof->id.c_str());
            ImGui::Text("Name: %s", prof->name.c_str());
            ImGui::Text("Email: %s", prof->email.c_str());
            ImGui::Text("Specialization: %s", prof->specialization.c_str());
            ImGui::Text("Schedule: %s", prof->schedule.c_str());
        }
        ImGui::EndTabItem();
    }

    ImGui::EndTabBar();
}
#endif
