#if HMS_HAS_SFML && HMS_HAS_IMGUI
#include "ui/App.h"
#include <imgui.h>
#include <string>

static char s_email[128] = "";
static char s_password[128] = "";
static int  s_roleIndex = 0;
static std::string s_loginError;

void renderLoginPanel(App& app) {
    const ImVec2 avail = ImGui::GetContentRegionAvail();
    const float boxW = 420.f, boxH = 430.f;
    ImGui::SetCursorPos({(avail.x - boxW) * 0.5f, (avail.y - boxH) * 0.35f});

    ImGui::BeginChild("##loginBox", {boxW, boxH}, ImGuiChildFlags_Borders);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, {8, 10});

    // Title
    float titleW = ImGui::CalcTextSize("Hospital Management System").x;
    ImGui::SetCursorPosX((boxW - titleW) * 0.5f);
    ImGui::TextColored({0.4f, 0.7f, 1.f, 1.f}, "Hospital Management System");
    ImGui::Separator();
    ImGui::Spacing();

    // Email
    ImGui::Text("Email");
    ImGui::SetNextItemWidth(-1);
    ImGui::InputText("##email", s_email, sizeof(s_email));

    // Password
    ImGui::Text("Password");
    ImGui::SetNextItemWidth(-1);
    ImGui::InputText("##pass", s_password, sizeof(s_password), ImGuiInputTextFlags_Password);

    // Role
    ImGui::Text("Role");
    ImGui::SetNextItemWidth(-1);
    const char* roles[] = {"Admin", "Doctor", "Patient"};
    ImGui::Combo("##role", &s_roleIndex, roles, 3);

    ImGui::Spacing();

    // Login button
    float btnW = 120.f;
    ImGui::SetCursorPosX((boxW - btnW) * 0.5f);
    if (ImGui::Button("Login", {btnW, 32})) {
        UserRole role = (s_roleIndex == 0) ? UserRole::Admin
                      : (s_roleIndex == 1) ? UserRole::Doctor
                      : UserRole::Patient;
        if (app.login(s_email, s_password, role)) {
            s_loginError.clear();
            s_email[0] = '\0';
            s_password[0] = '\0';
        } else {
            s_loginError = "Invalid email, password, or role.";
        }
    }

    // Error
    if (!s_loginError.empty()) {
        ImGui::Spacing();
        ImGui::TextColored({1.f, 0.35f, 0.35f, 1.f}, "%s", s_loginError.c_str());
    }

    // Credential hints
    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextColored({0.55f, 0.55f, 0.6f, 1.f}, "Test credentials:");
    ImGui::TextColored({0.55f, 0.55f, 0.6f, 1.f}, "  Admin:   admin1@hms.local / admin123");
    ImGui::TextColored({0.55f, 0.55f, 0.6f, 1.f}, "  Doctor:  doctor1@hms.local / doctor123");
    ImGui::TextColored({0.55f, 0.55f, 0.6f, 1.f}, "  Patient: patient1@hms.local / patient123");

    ImGui::PopStyleVar();
    ImGui::EndChild();
}
#endif
