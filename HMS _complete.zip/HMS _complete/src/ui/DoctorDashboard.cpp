#include "ui/DoctorDashboard.h"

#include "models/Doctor.h"
#include "models/Patient.h"
#include "utils/DateUtils.h"
#include "utils/HashUtils.h"

#include <algorithm>
#include <cctype>
#include <set>

DoctorDashboard::DoctorDashboard(UserManager& userManager,
                                 AppointmentManager& appointmentManager,
                                 MedicalRecordManager& medicalRecordManager)
    : userManager_(userManager),
      appointmentManager_(appointmentManager),
      medicalRecordManager_(medicalRecordManager) {}

bool DoctorDashboard::startSession(const std::string& doctorId) {
    const auto userOpt = userManager_.findById(doctorId);
    if (!userOpt.has_value()) {
        return false;
    }
    if (userOpt.value()->getRole() != UserRole::Doctor) {
        return false;
    }
    activeDoctorId_ = doctorId;
    return true;
}

void DoctorDashboard::logout() {
    activeDoctorId_.reset();
}

std::optional<std::string> DoctorDashboard::currentDoctorId() const {
    return activeDoctorId_;
}

std::optional<DoctorDashboard::DoctorProfile> DoctorDashboard::myProfile() const {
    if (!activeDoctorId_.has_value()) {
        return std::nullopt;
    }
    const auto user = userManager_.findById(activeDoctorId_.value());
    if (!user.has_value() || user.value()->getRole() != UserRole::Doctor) {
        return std::nullopt;
    }

    const auto* doctor = dynamic_cast<const Doctor*>(user.value());
    if (doctor == nullptr) {
        return std::nullopt;
    }

    DoctorProfile profile;
    profile.id = doctor->getId();
    profile.name = doctor->getName();
    profile.email = doctor->getEmail();
    profile.specialization = doctor->getSpecialization();
    profile.schedule = doctor->getSchedule();
    return profile;
}

std::vector<Appointment> DoctorDashboard::myAppointments(const bool includePast) const {
    if (!activeDoctorId_.has_value()) {
        return {};
    }

    std::vector<Appointment> appointments =
        appointmentManager_.listAppointments(activeDoctorId_, std::nullopt, std::nullopt, std::nullopt, std::nullopt);
    std::sort(appointments.begin(), appointments.end(), [](const Appointment& lhs, const Appointment& rhs) {
        return DateUtils::compareDateTime(lhs.getDateTime(), rhs.getDateTime()) < 0;
    });

    if (includePast) {
        return appointments;
    }

    const std::string now = DateUtils::currentDateTime();
    std::vector<Appointment> upcoming;
    for (const auto& appointment : appointments) {
        if (appointment.getStatus() == AppointmentStatus::Cancelled ||
            appointment.getStatus() == AppointmentStatus::Completed) {
            continue;
        }
        if (DateUtils::compareDateTime(appointment.getDateTime(), now) >= 0) {
            upcoming.push_back(appointment);
        }
    }
    return upcoming;
}

bool DoctorDashboard::acceptAppointment(const std::string& appointmentId) {
    const auto appointment = appointmentManager_.findById(appointmentId);
    if (!appointment.has_value() || !isOwnedAppointment(appointment.value())) {
        return false;
    }
    if (appointment.value().getStatus() == AppointmentStatus::Cancelled ||
        appointment.value().getStatus() == AppointmentStatus::Completed) {
        return false;
    }
    return appointmentManager_.updateStatus(appointmentId, AppointmentStatus::Accepted);
}

bool DoctorDashboard::cancelAppointment(const std::string& appointmentId) {
    const auto appointment = appointmentManager_.findById(appointmentId);
    if (!appointment.has_value() || !isOwnedAppointment(appointment.value())) {
        return false;
    }
    return appointmentManager_.cancelAppointment(appointmentId);
}

bool DoctorDashboard::completeAppointment(const std::string& appointmentId) {
    const auto appointment = appointmentManager_.findById(appointmentId);
    if (!appointment.has_value() || !isOwnedAppointment(appointment.value())) {
        return false;
    }
    if (appointment.value().getStatus() == AppointmentStatus::Cancelled) {
        return false;
    }
    return appointmentManager_.updateStatus(appointmentId, AppointmentStatus::Completed);
}

std::vector<const User*> DoctorDashboard::searchMyPatients(const std::string& query) const {
    if (!activeDoctorId_.has_value()) {
        return {};
    }

    const std::string queryLower = [&]() {
        std::string value = query;
        std::transform(value.begin(), value.end(), value.begin(), [](const unsigned char ch) {
            return static_cast<char>(std::tolower(ch));
        });
        return value;
    }();

    std::set<std::string> ownPatientIds;
    for (const auto& appointment : appointmentManager_.listAppointments(activeDoctorId_, std::nullopt, std::nullopt, std::nullopt, std::nullopt)) {
        ownPatientIds.insert(appointment.getPatientId());
    }
    for (const auto& record : medicalRecordManager_.listByDoctorId(activeDoctorId_.value())) {
        ownPatientIds.insert(record.getPatientId());
    }

    std::vector<const User*> matches;
    for (const std::string& patientId : ownPatientIds) {
        const auto patientOpt = userManager_.findById(patientId);
        if (!patientOpt.has_value() || patientOpt.value()->getRole() != UserRole::Patient) {
            continue;
        }
        if (query.empty()) {
            matches.push_back(patientOpt.value());
            continue;
        }

        std::string patientName = patientOpt.value()->getName();
        std::transform(patientName.begin(), patientName.end(), patientName.begin(), [](const unsigned char ch) {
            return static_cast<char>(std::tolower(ch));
        });

        if (patientOpt.value()->getId().find(query) != std::string::npos ||
            patientName.find(queryLower) != std::string::npos) {
            matches.push_back(patientOpt.value());
        }
    }
    return matches;
}

std::vector<MedicalRecord> DoctorDashboard::patientHistory(const std::string& patientId) const {
    if (!activeDoctorId_.has_value()) {
        return {};
    }
    if (!hasDoctorPatientRelationship(patientId)) {
        return {};
    }

    return medicalRecordManager_.listByPatientId(patientId);
}

bool DoctorDashboard::addMedicalRecord(const std::string& id,
                                       const std::string& patientId,
                                       const std::string& diagnosis,
                                       const std::string& prescription,
                                       const std::string& date) {
    if (!activeDoctorId_.has_value()) {
        return false;
    }
    if (!hasDoctorPatientRelationship(patientId)) {
        return false;
    }
    return medicalRecordManager_.addRecord(id, patientId, activeDoctorId_.value(), diagnosis, prescription, date);
}

bool DoctorDashboard::editMedicalRecord(const std::string& id,
                                        const std::string& diagnosis,
                                        const std::string& prescription,
                                        const std::string& date) {
    if (!activeDoctorId_.has_value()) {
        return false;
    }
    const auto record = medicalRecordManager_.findById(id);
    if (!record.has_value() || record.value().getDoctorId() != activeDoctorId_.value()) {
        return false;
    }
    return medicalRecordManager_.editRecord(id, diagnosis, prescription, date);
}

std::vector<DoctorDashboard::ScheduleSlot> DoctorDashboard::myWeeklySchedule(const std::string& weekStartDate,
                                                                              const int startHour,
                                                                              const int endHour) const {
    if (!activeDoctorId_.has_value()) {
        return {};
    }

    std::vector<ScheduleSlot> slots;
    std::set<std::string> busyDateTimes;
    std::vector<Appointment> all = appointmentManager_.listAppointments(activeDoctorId_, std::nullopt, std::nullopt, std::nullopt, std::nullopt);
    for (const auto& appointment : all) {
        if (appointment.getStatus() != AppointmentStatus::Cancelled) {
            busyDateTimes.insert(appointment.getDateTime());
        }
    }

    for (int dayOffset = 0; dayOffset < 7; ++dayOffset) {
        const auto day = DateUtils::addDays(weekStartDate, dayOffset);
        if (!day.has_value()) {
            continue;
        }
        const auto daySlots = DateUtils::generateDaySlots(day.value(), startHour, endHour);
        for (const auto& dt : daySlots) {
            ScheduleSlot slot;
            slot.dateTime = dt;
            slot.isBooked = busyDateTimes.find(dt) != busyDateTimes.end();
            if (slot.isBooked) {
                for (const auto& appointment : all) {
                    if (appointment.getDateTime() == dt && appointment.getStatus() != AppointmentStatus::Cancelled) {
                        slot.appointmentId = appointment.getId();
                        slot.patientId = appointment.getPatientId();
                        break;
                    }
                }
            }
            slots.push_back(slot);
        }
    }
    return slots;
}

bool DoctorDashboard::updateMyProfile(const std::string& name,
                                      const std::string& email,
                                      const std::string& specialization,
                                      const std::string& schedule,
                                      const std::optional<std::string>& newPlainPassword) {
    if (!activeDoctorId_.has_value()) {
        return false;
    }

    const auto currentUser = userManager_.findById(activeDoctorId_.value());
    if (!currentUser.has_value() || currentUser.value()->getRole() != UserRole::Doctor) {
        return false;
    }

    std::string hash = currentUser.value()->getPasswordHash();
    if (newPlainPassword.has_value() && !newPlainPassword->empty()) {
        hash = HashUtils::hashPassword(newPlainPassword.value());
    }

    if (!userManager_.updateUser(activeDoctorId_.value(), name, email, hash)) {
        return false;
    }
    return userManager_.updateDoctorDetails(activeDoctorId_.value(), specialization, schedule);
}

bool DoctorDashboard::isOwnedAppointment(const Appointment& appointment) const {
    return activeDoctorId_.has_value() && appointment.getDoctorId() == activeDoctorId_.value();
}

bool DoctorDashboard::hasDoctorPatientRelationship(const std::string& patientId) const {
    if (!activeDoctorId_.has_value()) {
        return false;
    }
    for (const auto& appointment : appointmentManager_.listAppointments(activeDoctorId_, patientId, std::nullopt, std::nullopt, std::nullopt)) {
        if (appointment.getStatus() != AppointmentStatus::Cancelled) {
            return true;
        }
    }
    for (const auto& record : medicalRecordManager_.listByDoctorId(activeDoctorId_.value())) {
        if (record.getPatientId() == patientId) {
            return true;
        }
    }
    return false;
}
