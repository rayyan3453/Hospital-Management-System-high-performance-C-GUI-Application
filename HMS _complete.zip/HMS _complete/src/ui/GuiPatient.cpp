#if HMS_HAS_SFML && HMS_HAS_IMGUI
#include "ui/App.h"
#include <imgui.h>
#include <string>
#include <vector>

static std::string s_pMsg;

void renderPatientPanel(App& app) {
    auto& dash = app.patientDashboard();

    ImGui::TextColored({0.4f,0.7f,1.f,1.f}, "Patient Dashboard");
    ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
    if (ImGui::Button("Logout", {80, 0})) { app.logout(); return; }
    ImGui::Separator();
    if (!s_pMsg.empty()) { ImGui::TextColored({0.2f,0.9f,0.4f,1.f}, "%s", s_pMsg.c_str()); }

    if (!ImGui::BeginTabBar("##patTabs")) return;

    // ── Book Appointment ──
    if (ImGui::BeginTabItem("Book")) {
        static int selSpec = -1;
        static int selDoc = -1;
        static int selSlot = -1;
        static std::vector<std::string> specs, slots;
        static std::vector<PatientDashboard::DoctorOption> docs;
        static char bookId[64]="", bookNotes[256]="";

        if (ImGui::Button("Refresh Specializations")) {
            specs = dash.availableSpecializations();
            selSpec = -1; selDoc = -1; selSlot = -1;
            docs.clear(); slots.clear();
        }

        // Specialization list
        if (!specs.empty()) {
            ImGui::Text("Specialization:");
            for (int i = 0; i < (int)specs.size(); i++) {
                if (ImGui::RadioButton(specs[i].c_str(), &selSpec, i)) {
                    docs = dash.doctorsBySpecialization(specs[i]);
                    selDoc = -1; selSlot = -1; slots.clear();
                }
            }
        }

        // Doctor list
        if (selSpec >= 0 && !docs.empty()) {
            ImGui::Separator();
            ImGui::Text("Doctor:");
            for (int i = 0; i < (int)docs.size(); i++) {
                std::string label = docs[i].name + " (" + docs[i].specialization + ")";
                if (ImGui::RadioButton(label.c_str(), &selDoc, i)) {
                    // show slots for tomorrow
                    slots = dash.availableSlotsForDoctor(docs[i].id, "2026-05-11");
                    selSlot = -1;
                }
            }
        }

        // Slot list
        if (selDoc >= 0 && !slots.empty()) {
            ImGui::Separator();
            ImGui::Text("Available Slots (2026-05-11):");
            for (int i = 0; i < (int)slots.size(); i++) {
                ImGui::RadioButton(slots[i].c_str(), &selSlot, i);
            }
        }

        // Book form
        if (selSlot >= 0) {
            ImGui::Separator();
            ImGui::InputText("Appointment ID", bookId, sizeof(bookId));
            ImGui::InputText("Notes", bookNotes, sizeof(bookNotes));
            if (ImGui::Button("Book Now")) {
                if (dash.bookAppointment(bookId, docs[selDoc].id, slots[selSlot], bookNotes)) {
                    s_pMsg = "Appointment booked!";
                    bookId[0]=bookNotes[0]='\0'; selSlot=-1;
                } else {
                    s_pMsg = "Booking failed.";
                }
            }
        }
        ImGui::EndTabItem();
    }

    // ── My Appointments ──
    if (ImGui::BeginTabItem("Appointments")) {
        auto appts = dash.myAppointments(true);
        if (ImGui::BeginTable("##pAppts", 6, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY)) {
            ImGui::TableSetupColumn("ID"); ImGui::TableSetupColumn("Doctor");
            ImGui::TableSetupColumn("DateTime"); ImGui::TableSetupColumn("Status");
            ImGui::TableSetupColumn("Notes"); ImGui::TableSetupColumn("Actions", ImGuiTableColumnFlags_WidthFixed, 70);
            ImGui::TableHeadersRow();
            for (auto& a : appts) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(a.getId().c_str());
                ImGui::TableSetColumnIndex(1); ImGui::TextUnformatted(a.getDoctorId().c_str());
                ImGui::TableSetColumnIndex(2); ImGui::TextUnformatted(a.getDateTime().c_str());
                ImGui::TableSetColumnIndex(3); ImGui::TextUnformatted(toString(a.getStatus()).c_str());
                ImGui::TableSetColumnIndex(4); ImGui::TextUnformatted(a.getNotes().c_str());
                ImGui::TableSetColumnIndex(5);
                ImGui::PushID(a.getId().c_str());
                auto st = a.getStatus();
                if (st == AppointmentStatus::Pending || st == AppointmentStatus::Accepted) {
                    if (ImGui::SmallButton("Cancel")) { dash.cancelMyAppointment(a.getId()); s_pMsg="Cancelled."; }
                }
                ImGui::PopID();
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Records ──
    if (ImGui::BeginTabItem("Records")) {
        auto recs = dash.myMedicalHistory();
        if (ImGui::BeginTable("##pRecs", 5, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY)) {
            ImGui::TableSetupColumn("Date"); ImGui::TableSetupColumn("Doctor");
            ImGui::TableSetupColumn("Diagnosis"); ImGui::TableSetupColumn("Prescription");
            ImGui::TableSetupColumn("Record ID");
            ImGui::TableHeadersRow();
            for (auto& r : recs) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(r.date.c_str());
                ImGui::TableSetColumnIndex(1); ImGui::TextUnformatted(r.doctorName.c_str());
                ImGui::TableSetColumnIndex(2); ImGui::TextUnformatted(r.diagnosis.c_str());
                ImGui::TableSetColumnIndex(3); ImGui::TextUnformatted(r.prescription.c_str());
                ImGui::TableSetColumnIndex(4); ImGui::TextUnformatted(r.recordId.c_str());
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Billing ──
    if (ImGui::BeginTabItem("Billing")) {
        auto invoices = dash.myInvoices();
        if (ImGui::BeginTable("##pBills", 5, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg)) {
            ImGui::TableSetupColumn("ID"); ImGui::TableSetupColumn("Amount");
            ImGui::TableSetupColumn("Paid"); ImGui::TableSetupColumn("Date");
            ImGui::TableSetupColumn("Items");
            ImGui::TableHeadersRow();
            for (auto& inv : invoices) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(inv.billId.c_str());
                ImGui::TableSetColumnIndex(1); ImGui::Text("%.2f", inv.amount);
                ImGui::TableSetColumnIndex(2); ImGui::Text("%s", inv.isPaid?"Yes":"No");
                ImGui::TableSetColumnIndex(3); ImGui::TextUnformatted(inv.date.c_str());
                ImGui::TableSetColumnIndex(4); ImGui::TextUnformatted(inv.itemizedList.c_str());
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Profile ──
    if (ImGui::BeginTabItem("Profile")) {
        auto prof = dash.myProfile();
        if (prof) {
            ImGui::Text("ID: %s", prof->id.c_str());
            ImGui::Text("Name: %s", prof->name.c_str());
            ImGui::Text("Email: %s", prof->email.c_str());
            ImGui::Text("Date of Birth: %s", prof->dateOfBirth.c_str());
            ImGui::Text("Medical History: %s", prof->medicalHistory.c_str());
        }
        ImGui::EndTabItem();
    }

    ImGui::EndTabBar();
}
#endif
