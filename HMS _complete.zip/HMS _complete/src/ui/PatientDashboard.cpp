#include "ui/PatientDashboard.h"

#include "models/Patient.h"
#include "models/Doctor.h"
#include "utils/DateUtils.h"
#include "utils/HashUtils.h"

#include <algorithm>
#include <set>

PatientDashboard::PatientDashboard(UserManager& userManager,
                                   AppointmentManager& appointmentManager,
                                   MedicalRecordManager& medicalRecordManager,
                                   BillingManager& billingManager)
    : userManager_(userManager),
      appointmentManager_(appointmentManager),
      medicalRecordManager_(medicalRecordManager),
      billingManager_(billingManager) {}

bool PatientDashboard::startSession(const std::string& patientId) {
    const auto user = userManager_.findById(patientId);
    if (!user.has_value() || user.value()->getRole() != UserRole::Patient) {
        return false;
    }
    activePatientId_ = patientId;
    return true;
}

void PatientDashboard::logout() {
    activePatientId_.reset();
}

std::optional<std::string> PatientDashboard::currentPatientId() const {
    return activePatientId_;
}

std::optional<PatientDashboard::PatientProfile> PatientDashboard::myProfile() const {
    if (!activePatientId_.has_value()) {
        return std::nullopt;
    }

    const auto user = userManager_.findById(activePatientId_.value());
    if (!user.has_value() || user.value()->getRole() != UserRole::Patient) {
        return std::nullopt;
    }

    const auto* patient = dynamic_cast<const Patient*>(user.value());
    if (patient == nullptr) {
        return std::nullopt;
    }

    PatientProfile profile;
    profile.id = patient->getId();
    profile.name = patient->getName();
    profile.email = patient->getEmail();
    profile.dateOfBirth = patient->getDateOfBirth();
    profile.medicalHistory = patient->getMedicalHistory();
    return profile;
}

std::vector<std::string> PatientDashboard::availableSpecializations() const {
    std::set<std::string> specializations;
    for (const User* user : userManager_.getAllUsers()) {
        if (user->getRole() != UserRole::Doctor) {
            continue;
        }
        const auto* doctor = dynamic_cast<const Doctor*>(user);
        if (doctor != nullptr && !doctor->getSpecialization().empty()) {
            specializations.insert(doctor->getSpecialization());
        }
    }
    return {specializations.begin(), specializations.end()};
}

std::vector<PatientDashboard::DoctorOption> PatientDashboard::doctorsBySpecialization(const std::string& specialization) const {
    std::vector<DoctorOption> doctors;
    for (const User* user : userManager_.getAllUsers()) {
        if (user->getRole() != UserRole::Doctor) {
            continue;
        }
        const auto* doctor = dynamic_cast<const Doctor*>(user);
        if (doctor == nullptr) {
            continue;
        }
        if (!specialization.empty() && doctor->getSpecialization() != specialization) {
            continue;
        }
        doctors.push_back({doctor->getId(), doctor->getName(), doctor->getSpecialization()});
    }
    std::sort(doctors.begin(), doctors.end(), [](const DoctorOption& lhs, const DoctorOption& rhs) {
        return lhs.name < rhs.name;
    });
    return doctors;
}

std::vector<std::string> PatientDashboard::availableSlotsForDoctor(const std::string& doctorId,
                                                                   const std::string& date,
                                                                   const int startHour,
                                                                   const int endHour) const {
    if (!DateUtils::isValidDate(date)) {
        return {};
    }

    std::set<std::string> takenSlots;
    const auto doctorAppointments = appointmentManager_.listAppointments(doctorId, std::nullopt, std::nullopt, std::nullopt, std::nullopt);
    for (const auto& appointment : doctorAppointments) {
        if (appointment.getStatus() != AppointmentStatus::Cancelled) {
            takenSlots.insert(appointment.getDateTime());
        }
    }

    const auto allSlots = DateUtils::generateDaySlots(date, startHour, endHour);
    std::vector<std::string> available;
    for (const auto& slot : allSlots) {
        if (takenSlots.find(slot) == takenSlots.end()) {
            available.push_back(slot);
        }
    }
    return available;
}

bool PatientDashboard::bookAppointment(const std::string& appointmentId,
                                       const std::string& doctorId,
                                       const std::string& dateTime,
                                       const std::string& notes) {
    if (!activePatientId_.has_value()) {
        return false;
    }
    if (!DateUtils::isValidDateTime(dateTime)) {
        return false;
    }

    const std::string date = dateTime.substr(0, 10);
    const auto available = availableSlotsForDoctor(doctorId, date);
    if (std::find(available.begin(), available.end(), dateTime) == available.end()) {
        return false;
    }

    return appointmentManager_.scheduleAppointment(appointmentId, activePatientId_.value(), doctorId, dateTime, notes);
}

std::vector<Appointment> PatientDashboard::myAppointments(const bool includePast) const {
    if (!activePatientId_.has_value()) {
        return {};
    }

    std::vector<Appointment> appointments = appointmentManager_.listAppointments(
        std::nullopt, activePatientId_, std::nullopt, std::nullopt, std::nullopt);

    std::sort(appointments.begin(), appointments.end(), [](const Appointment& lhs, const Appointment& rhs) {
        return DateUtils::compareDateTime(lhs.getDateTime(), rhs.getDateTime()) < 0;
    });

    if (includePast) {
        return appointments;
    }

    const std::string now = DateUtils::currentDateTime();
    std::vector<Appointment> upcoming;
    for (const auto& appointment : appointments) {
        if (appointment.getStatus() == AppointmentStatus::Cancelled ||
            appointment.getStatus() == AppointmentStatus::Completed) {
            continue;
        }
        if (DateUtils::compareDateTime(appointment.getDateTime(), now) >= 0) {
            upcoming.push_back(appointment);
        }
    }
    return upcoming;
}

bool PatientDashboard::cancelMyAppointment(const std::string& appointmentId) {
    const auto appointment = appointmentManager_.findById(appointmentId);
    if (!appointment.has_value() || !isOwnedAppointment(appointment.value())) {
        return false;
    }
    if (appointment.value().getStatus() == AppointmentStatus::Completed ||
        appointment.value().getStatus() == AppointmentStatus::Cancelled) {
        return false;
    }
    return appointmentManager_.cancelAppointment(appointmentId);
}

std::vector<PatientDashboard::MedicalHistoryEntry> PatientDashboard::myMedicalHistory() const {
    if (!activePatientId_.has_value()) {
        return {};
    }

    std::vector<MedicalHistoryEntry> history;
    for (const auto& record : medicalRecordManager_.listByPatientId(activePatientId_.value())) {
        MedicalHistoryEntry entry;
        entry.recordId = record.getId();
        entry.diagnosis = record.getDiagnosis();
        entry.prescription = record.getPrescription();
        entry.date = record.getDate();
        entry.doctorId = record.getDoctorId();

        const auto doctor = userManager_.findById(record.getDoctorId());
        entry.doctorName = (doctor.has_value() ? doctor.value()->getName() : "Unknown Doctor");
        history.push_back(entry);
    }

    std::sort(history.begin(), history.end(), [](const MedicalHistoryEntry& lhs, const MedicalHistoryEntry& rhs) {
        return lhs.date > rhs.date;
    });
    return history;
}

std::vector<PatientDashboard::InvoiceEntry> PatientDashboard::myInvoices() const {
    if (!activePatientId_.has_value()) {
        return {};
    }

    std::vector<InvoiceEntry> invoices;
    for (const auto& bill : billingManager_.listByPatientId(activePatientId_.value())) {
        invoices.push_back({bill.getId(), bill.getAmount(), bill.getIsPaid(), bill.getDate(), bill.getItemizedList()});
    }
    std::sort(invoices.begin(), invoices.end(), [](const InvoiceEntry& lhs, const InvoiceEntry& rhs) {
        return lhs.date > rhs.date;
    });
    return invoices;
}

bool PatientDashboard::updateMyProfile(const std::string& name,
                                       const std::string& email,
                                       const std::string& dateOfBirth,
                                       const std::string& medicalHistory,
                                       const std::optional<std::string>& newPlainPassword) {
    if (!activePatientId_.has_value()) {
        return false;
    }

    const auto current = userManager_.findById(activePatientId_.value());
    if (!current.has_value() || current.value()->getRole() != UserRole::Patient) {
        return false;
    }

    std::string hash = current.value()->getPasswordHash();
    if (newPlainPassword.has_value() && !newPlainPassword->empty()) {
        hash = HashUtils::hashPassword(newPlainPassword.value());
    }

    if (!userManager_.updateUser(activePatientId_.value(), name, email, hash)) {
        return false;
    }
    return userManager_.updatePatientDetails(activePatientId_.value(), dateOfBirth, medicalHistory);
}

bool PatientDashboard::isOwnedAppointment(const Appointment& appointment) const {
    return activePatientId_.has_value() && appointment.getPatientId() == activePatientId_.value();
}
