#include "ui/App.h"

#include <stdexcept>

#if HMS_HAS_SFML && HMS_HAS_IMGUI
#include <SFML/Graphics.hpp>
#include <imgui-SFML.h>
#include <imgui.h>
#include <imgui_stdlib.h>
#endif

// Forward declarations for panel renderers (defined in GuiPanels.cpp)
#if HMS_HAS_SFML && HMS_HAS_IMGUI
void renderLoginPanel(App& app);
void renderAdminPanel(App& app);
void renderDoctorPanel(App& app);
void renderPatientPanel(App& app);
#endif

App::App() {
    reportManager_ = std::make_unique<ReportManager>(userManager_, appointmentManager_);
    loginScreen_ = std::make_unique<LoginScreen>(userManager_);
    adminDashboard_ = std::make_unique<AdminDashboard>(
        userManager_, appointmentManager_, medicalRecordManager_, billingManager_, roomManager_, *reportManager_);
    doctorDashboard_ = std::make_unique<DoctorDashboard>(userManager_, appointmentManager_, medicalRecordManager_);
    patientDashboard_ = std::make_unique<PatientDashboard>(userManager_, appointmentManager_, medicalRecordManager_, billingManager_);
}

void App::initialize(const std::string& dataDirectory) {
    dataDirectory_ = dataDirectory;
    userManager_.loadFromFile(dataDirectory_ + "/users.csv");
    appointmentManager_.loadFromFile(dataDirectory_ + "/appointments.csv");
    medicalRecordManager_.loadFromFile(dataDirectory_ + "/medical_records.csv");
    billingManager_.loadFromFile(dataDirectory_ + "/billing.csv");
    roomManager_.loadFromFile(dataDirectory_ + "/rooms.csv");
    route_ = Route::Login;
}

void App::run() {
#if HMS_HAS_SFML && HMS_HAS_IMGUI
    sf::RenderWindow window(sf::VideoMode({1280u, 800u}), "Hospital Management System");
    window.setFramerateLimit(60);

    // Create ImGui context manually so we can configure fonts BEFORE Init
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr; // disable imgui.ini file

    // Force RGBA32 pixel format — ImGui-SFML's UpdateFontTexture calls
    // sf::Texture::update(uint8_t*) which expects exactly 4 bytes per pixel.
    // Without this, ImGui 1.92 may produce Alpha8 data, corrupting certain glyphs.
    io.Fonts->TexDesiredFormat = ImTextureFormat_RGBA32;

    // Load a real TTF font — required for ImGui 1.92+ with ImGui-SFML 3.0.
    const char* fontPaths[] = {
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibri.ttf"
    };
    bool fontLoaded = false;
    for (const char* path : fontPaths) {
        if (io.Fonts->AddFontFromFileTTF(path, 16.0f)) {
            fontLoaded = true;
            break;
        }
    }
    if (!fontLoaded) {
        io.Fonts->AddFontDefault();
    }

    // Pre-build font atlas before Init so SFML gets clean RGBA32 data
    io.Fonts->Build();

    if (!ImGui::SFML::Init(window)) {
        throw std::runtime_error("ImGui-SFML init failed");
    }

    // Style — dark theme with accent colour
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding    = 6.f;
    style.FrameRounding     = 4.f;
    style.ScrollbarRounding = 4.f;
    style.GrabRounding      = 4.f;
    style.WindowPadding     = {14.f, 14.f};
    style.FramePadding      = {8.f, 4.f};
    style.ItemSpacing       = {8.f, 6.f};
    ImVec4* c = style.Colors;
    c[ImGuiCol_Text]             = {1.00f, 1.00f, 1.00f, 1.f};
    c[ImGuiCol_TextDisabled]     = {0.60f, 0.62f, 0.65f, 1.f};
    c[ImGuiCol_WindowBg]         = {0.10f, 0.12f, 0.16f, 1.f};
    c[ImGuiCol_ChildBg]          = {0.12f, 0.14f, 0.19f, 1.f};
    c[ImGuiCol_Header]           = {0.18f, 0.46f, 0.78f, 0.8f};
    c[ImGuiCol_HeaderHovered]    = {0.22f, 0.55f, 0.90f, 0.9f};
    c[ImGuiCol_HeaderActive]     = {0.16f, 0.40f, 0.70f, 1.f};
    c[ImGuiCol_Button]           = {0.18f, 0.46f, 0.78f, 0.85f};
    c[ImGuiCol_ButtonHovered]    = {0.22f, 0.55f, 0.90f, 1.f};
    c[ImGuiCol_ButtonActive]     = {0.14f, 0.38f, 0.66f, 1.f};
    c[ImGuiCol_Tab]              = {0.14f, 0.35f, 0.60f, 0.8f};
    c[ImGuiCol_TabHovered]       = {0.22f, 0.55f, 0.90f, 1.f};
    c[ImGuiCol_TabSelected]      = {0.18f, 0.46f, 0.78f, 1.f};
    c[ImGuiCol_TitleBgActive]    = {0.12f, 0.30f, 0.54f, 1.f};
    c[ImGuiCol_FrameBg]          = {0.24f, 0.28f, 0.38f, 1.f};
    c[ImGuiCol_FrameBgHovered]   = {0.30f, 0.35f, 0.46f, 1.f};
    c[ImGuiCol_FrameBgActive]    = {0.32f, 0.38f, 0.50f, 1.f};

    sf::Clock deltaClock;
    while (window.isOpen()) {
        while (const std::optional<sf::Event> event = window.pollEvent()) {
            ImGui::SFML::ProcessEvent(window, *event);
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
        }

        ImGui::SFML::Update(window, deltaClock.restart());

        // Full-screen dockspace host window
        const sf::Vector2u sz = window.getSize();
        ImGui::SetNextWindowPos({0, 0});
        ImGui::SetNextWindowSize({static_cast<float>(sz.x), static_cast<float>(sz.y)});
        ImGui::Begin("##host", nullptr,
            ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
            ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus);

        switch (route_) {
            case Route::Login:          renderLoginPanel(*this);   break;
            case Route::AdminDashboard: renderAdminPanel(*this);   break;
            case Route::DoctorDashboard:renderDoctorPanel(*this);  break;
            case Route::PatientDashboard:renderPatientPanel(*this);break;
        }

        ImGui::End();

        window.clear({26, 31, 42, 255});
        ImGui::SFML::Render(window);
        window.display();
    }

    ImGui::SFML::Shutdown();
#else
    throw std::runtime_error("SFML/ImGui not compiled in — rebuild with vcpkg toolchain.");
#endif
}

bool App::login(const std::string& email, const std::string& plainPassword, const UserRole role) {
    const auto session = loginScreen_->login(email, plainPassword, role);
    if (!session.has_value()) return false;
    if (session->role == UserRole::Admin) {
        if (!adminDashboard_->startSession(session->userId)) return false;
        route_ = Route::AdminDashboard;
    } else if (session->role == UserRole::Doctor) {
        if (!doctorDashboard_->startSession(session->userId)) return false;
        route_ = Route::DoctorDashboard;
    } else if (session->role == UserRole::Patient) {
        if (!patientDashboard_->startSession(session->userId)) return false;
        route_ = Route::PatientDashboard;
    } else return false;
    return true;
}

void App::logout() {
    if (route_ == Route::AdminDashboard)       adminDashboard_->logout();
    else if (route_ == Route::DoctorDashboard) doctorDashboard_->logout();
    else if (route_ == Route::PatientDashboard)patientDashboard_->logout();
    route_ = Route::Login;
}

App::Route App::currentRoute() const { return route_; }
LoginScreen&     App::loginScreen()      { return *loginScreen_; }
AdminDashboard&  App::adminDashboard()   { return *adminDashboard_; }
DoctorDashboard& App::doctorDashboard()  { return *doctorDashboard_; }
PatientDashboard&App::patientDashboard() { return *patientDashboard_; }
