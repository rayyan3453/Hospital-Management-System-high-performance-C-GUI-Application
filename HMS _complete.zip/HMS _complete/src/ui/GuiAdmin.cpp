#if HMS_HAS_SFML && HMS_HAS_IMGUI
#include "ui/App.h"
#include "models/Doctor.h"
#include "models/Patient.h"
#include <imgui.h>
#include <string>
#include <cstring>

static char s_aSearchName[128] = "";
static int  s_aRoleFilter = 0; // 0=All,1=Admin,2=Doctor,3=Patient

// Add user form state
static bool s_aShowAdd = false;
static int  s_aAddType = 0; // 0=Doctor,1=Patient
static char s_aAddId[64]="", s_aAddName[128]="", s_aAddEmail[128]="", s_aAddPass[128]="";
static char s_aAddExtra1[128]="", s_aAddExtra2[256]="";
static std::string s_aMsg;

// Room form
static char s_aRoomId[64]="", s_aRoomType[64]="", s_aRoomPatient[64]="";

void renderAdminPanel(App& app) {
    auto& dash = app.adminDashboard();

    // Header bar
    ImGui::TextColored({0.4f,0.7f,1.f,1.f}, "Admin Dashboard");
    ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80);
    if (ImGui::Button("Logout", {80, 0})) { app.logout(); return; }
    ImGui::Separator();

    if (!ImGui::BeginTabBar("##adminTabs")) return;

    // ── Users Tab ──
    if (ImGui::BeginTabItem("Users")) {
        ImGui::SetNextItemWidth(200);
        ImGui::InputText("Search##u", s_aSearchName, sizeof(s_aSearchName));
        ImGui::SameLine();
        ImGui::SetNextItemWidth(120);
        const char* rf[] = {"All","Admin","Doctor","Patient"};
        ImGui::Combo("Role##u", &s_aRoleFilter, rf, 4);
        ImGui::SameLine();
        if (ImGui::Button("Add User")) s_aShowAdd = !s_aShowAdd;

        if (!s_aMsg.empty()) { ImGui::TextColored({0.2f,0.9f,0.4f,1.f}, "%s", s_aMsg.c_str()); }

        // Add form
        if (s_aShowAdd) {
            ImGui::BeginChild("##addUser", {0, 180}, ImGuiChildFlags_Borders);
            const char* types[] = {"Doctor","Patient"};
            ImGui::Combo("Type", &s_aAddType, types, 2);
            ImGui::InputText("ID", s_aAddId, sizeof(s_aAddId));
            ImGui::InputText("Name", s_aAddName, sizeof(s_aAddName));
            ImGui::InputText("Email", s_aAddEmail, sizeof(s_aAddEmail));
            ImGui::InputText("Password", s_aAddPass, sizeof(s_aAddPass));
            if (s_aAddType == 0) {
                ImGui::InputText("Specialization", s_aAddExtra1, sizeof(s_aAddExtra1));
                ImGui::InputText("Schedule", s_aAddExtra2, sizeof(s_aAddExtra2));
            } else {
                ImGui::InputText("Date of Birth", s_aAddExtra1, sizeof(s_aAddExtra1));
                ImGui::InputText("Medical History", s_aAddExtra2, sizeof(s_aAddExtra2));
            }
            if (ImGui::Button("Save")) {
                bool ok = false;
                if (s_aAddType == 0)
                    ok = dash.addDoctor(s_aAddId, s_aAddName, s_aAddEmail, s_aAddPass, s_aAddExtra1, s_aAddExtra2);
                else
                    ok = dash.addPatient(s_aAddId, s_aAddName, s_aAddEmail, s_aAddPass, s_aAddExtra1, s_aAddExtra2);
                s_aMsg = ok ? "User added." : "Failed (duplicate ID/email?).";
                if (ok) { s_aShowAdd = false; s_aAddId[0]=s_aAddName[0]=s_aAddEmail[0]=s_aAddPass[0]=s_aAddExtra1[0]=s_aAddExtra2[0]='\0'; }
            }
            ImGui::SameLine();
            if (ImGui::Button("Cancel")) s_aShowAdd = false;
            ImGui::EndChild();
        }

        // User list table
        std::optional<UserRole> roleF;
        if (s_aRoleFilter == 1) roleF = UserRole::Admin;
        else if (s_aRoleFilter == 2) roleF = UserRole::Doctor;
        else if (s_aRoleFilter == 3) roleF = UserRole::Patient;
        auto users = dash.users(s_aSearchName, roleF);

        if (ImGui::BeginTable("##usersTbl", 5, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY)) {
            ImGui::TableSetupColumn("ID");
            ImGui::TableSetupColumn("Name");
            ImGui::TableSetupColumn("Email");
            ImGui::TableSetupColumn("Role");
            ImGui::TableSetupColumn("Actions", ImGuiTableColumnFlags_WidthFixed, 80);
            ImGui::TableHeadersRow();
            for (const auto* u : users) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(u->getId().c_str());
                ImGui::TableSetColumnIndex(1); ImGui::TextUnformatted(u->getName().c_str());
                ImGui::TableSetColumnIndex(2); ImGui::TextUnformatted(u->getEmail().c_str());
                ImGui::TableSetColumnIndex(3); ImGui::TextUnformatted(toString(u->getRole()).c_str());
                ImGui::TableSetColumnIndex(4);
                ImGui::PushID(u->getId().c_str());
                if (ImGui::SmallButton("Del")) {
                    if (dash.deleteUser(u->getId())) s_aMsg = "Deleted.";
                    else s_aMsg = "Cannot delete.";
                }
                ImGui::PopID();
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Rooms Tab ──
    if (ImGui::BeginTabItem("Rooms")) {
        ImGui::InputText("Room ID", s_aRoomId, sizeof(s_aRoomId));
        ImGui::SameLine(); ImGui::InputText("Type", s_aRoomType, sizeof(s_aRoomType));
        ImGui::SameLine();
        if (ImGui::Button("Add Room")) {
            if (dash.addRoom(s_aRoomId, s_aRoomType)) { s_aMsg = "Room added."; s_aRoomId[0]=s_aRoomType[0]='\0'; }
            else s_aMsg = "Failed.";
        }
        if (!s_aMsg.empty()) ImGui::TextColored({0.2f,0.9f,0.4f,1.f}, "%s", s_aMsg.c_str());

        auto rooms = dash.rooms();
        if (ImGui::BeginTable("##roomsTbl", 5, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg)) {
            ImGui::TableSetupColumn("ID"); ImGui::TableSetupColumn("Type");
            ImGui::TableSetupColumn("Occupied"); ImGui::TableSetupColumn("Patient");
            ImGui::TableSetupColumn("Actions", ImGuiTableColumnFlags_WidthFixed, 140);
            ImGui::TableHeadersRow();
            for (auto& r : rooms) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(r.getId().c_str());
                ImGui::TableSetColumnIndex(1); ImGui::TextUnformatted(r.getType().c_str());
                ImGui::TableSetColumnIndex(2); ImGui::Text("%s", r.getIsOccupied() ? "Yes":"No");
                ImGui::TableSetColumnIndex(3); ImGui::TextUnformatted(r.getAssignedPatientId().c_str());
                ImGui::TableSetColumnIndex(4);
                ImGui::PushID(r.getId().c_str());
                if (!r.getIsOccupied()) {
                    ImGui::SetNextItemWidth(80);
                    ImGui::InputText("##rp", s_aRoomPatient, sizeof(s_aRoomPatient));
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Assign")) dash.assignRoom(r.getId(), s_aRoomPatient);
                } else {
                    if (ImGui::SmallButton("Release")) dash.releaseRoom(r.getId());
                }
                ImGui::PopID();
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Appointments Tab ──
    if (ImGui::BeginTabItem("Appointments")) {
        auto appts = dash.appointments(std::nullopt, std::nullopt, std::nullopt, std::nullopt);
        if (ImGui::BeginTable("##apptsTbl", 6, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY)) {
            ImGui::TableSetupColumn("ID"); ImGui::TableSetupColumn("Patient");
            ImGui::TableSetupColumn("Doctor"); ImGui::TableSetupColumn("DateTime");
            ImGui::TableSetupColumn("Status"); ImGui::TableSetupColumn("Actions", ImGuiTableColumnFlags_WidthFixed, 70);
            ImGui::TableHeadersRow();
            for (auto& a : appts) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(a.getId().c_str());
                ImGui::TableSetColumnIndex(1); ImGui::TextUnformatted(a.getPatientId().c_str());
                ImGui::TableSetColumnIndex(2); ImGui::TextUnformatted(a.getDoctorId().c_str());
                ImGui::TableSetColumnIndex(3); ImGui::TextUnformatted(a.getDateTime().c_str());
                ImGui::TableSetColumnIndex(4); ImGui::TextUnformatted(toString(a.getStatus()).c_str());
                ImGui::TableSetColumnIndex(5);
                ImGui::PushID(a.getId().c_str());
                if (a.getStatus() != AppointmentStatus::Cancelled && a.getStatus() != AppointmentStatus::Completed) {
                    if (ImGui::SmallButton("Cancel")) dash.cancelAppointment(a.getId());
                }
                ImGui::PopID();
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Billing Tab ──
    if (ImGui::BeginTabItem("Billing")) {
        auto bov = dash.billingOverview();
        ImGui::Text("Total Revenue: %.2f  |  Outstanding: %.2f", bov.summary.totalRevenue, bov.summary.outstandingAmount);
        ImGui::Separator();
        if (ImGui::BeginTable("##billTbl", 6, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY)) {
            ImGui::TableSetupColumn("ID"); ImGui::TableSetupColumn("Patient");
            ImGui::TableSetupColumn("Amount"); ImGui::TableSetupColumn("Paid");
            ImGui::TableSetupColumn("Date"); ImGui::TableSetupColumn("Toggle", ImGuiTableColumnFlags_WidthFixed, 70);
            ImGui::TableHeadersRow();
            for (auto& b : bov.allBills) {
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0); ImGui::TextUnformatted(b.getId().c_str());
                ImGui::TableSetColumnIndex(1); ImGui::TextUnformatted(b.getPatientId().c_str());
                ImGui::TableSetColumnIndex(2); ImGui::Text("%.2f", b.getAmount());
                ImGui::TableSetColumnIndex(3); ImGui::Text("%s", b.getIsPaid()?"Yes":"No");
                ImGui::TableSetColumnIndex(4); ImGui::TextUnformatted(b.getDate().c_str());
                ImGui::TableSetColumnIndex(5);
                ImGui::PushID(b.getId().c_str());
                if (ImGui::SmallButton(b.getIsPaid()?"Unpay":"Pay")) dash.setBillPaid(b.getId(), !b.getIsPaid());
                ImGui::PopID();
            }
            ImGui::EndTable();
        }
        ImGui::EndTabItem();
    }

    // ── Reports Tab ──
    if (ImGui::BeginTabItem("Reports")) {
        auto s = dash.reportSummary();
        ImGui::Text("Admins: %d  |  Doctors: %d  |  Patients: %d", s.adminCount, s.doctorCount, s.patientCount);
        ImGui::Text("Pending: %d  |  Completed: %d  |  Cancelled: %d  |  Total: %d",
            s.pendingAppointments, s.completedAppointments, s.cancelledAppointments, s.totalAppointments);
        ImGui::EndTabItem();
    }

    ImGui::EndTabBar();
}
#endif
