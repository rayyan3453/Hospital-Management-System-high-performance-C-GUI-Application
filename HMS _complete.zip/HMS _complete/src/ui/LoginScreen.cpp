#include "ui/LoginScreen.h"

LoginScreen::LoginScreen(UserManager& userManager)
    : userManager_(userManager) {}

std::optional<LoginScreen::Session> LoginScreen::login(const std::string& email,
                                                       const std::string& plainPassword,
                                                       const UserRole role) const {
    const auto user = userManager_.login(email, plainPassword, role);
    if (!user.has_value()) {
        return std::nullopt;
    }
    return Session{user.value()->getId(), user.value()->getRole()};
}
