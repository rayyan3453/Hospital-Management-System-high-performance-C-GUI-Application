#include "ui/AdminDashboard.h"

#include "models/Doctor.h"
#include "models/Patient.h"
#include "utils/HashUtils.h"

AdminDashboard::AdminDashboard(UserManager& userManager,
                               AppointmentManager& appointmentManager,
                               MedicalRecordManager& medicalRecordManager,
                               BillingManager& billingManager,
                               RoomManager& roomManager,
                               ReportManager& reportManager)
    : userManager_(userManager),
      appointmentManager_(appointmentManager),
      medicalRecordManager_(medicalRecordManager),
      billingManager_(billingManager),
      roomManager_(roomManager),
      reportManager_(reportManager) {}

bool AdminDashboard::startSession(const std::string& adminId) {
    const auto user = userManager_.findById(adminId);
    if (!user.has_value() || user.value()->getRole() != UserRole::Admin) {
        return false;
    }
    activeAdminId_ = adminId;
    return true;
}

void AdminDashboard::logout() {
    activeAdminId_.reset();
}

std::optional<std::string> AdminDashboard::currentAdminId() const {
    return activeAdminId_;
}

std::vector<const User*> AdminDashboard::users(const std::string& nameQuery,
                                               const std::optional<UserRole> roleFilter) const {
    if (!sessionActive()) {
        return {};
    }
    return userManager_.searchUsers(nameQuery, roleFilter);
}

bool AdminDashboard::addDoctor(const std::string& id,
                               const std::string& name,
                               const std::string& email,
                               const std::string& plainPassword,
                               const std::string& specialization,
                               const std::string& schedule) {
    if (!sessionActive()) {
        return false;
    }
    userManager_.addDoctor(Doctor(id, name, email, HashUtils::hashPassword(plainPassword), specialization, schedule));
    return true;
}

bool AdminDashboard::addPatient(const std::string& id,
                                const std::string& name,
                                const std::string& email,
                                const std::string& plainPassword,
                                const std::string& dateOfBirth,
                                const std::string& medicalHistory) {
    if (!sessionActive()) {
        return false;
    }
    userManager_.addPatient(Patient(id, name, email, HashUtils::hashPassword(plainPassword), dateOfBirth, medicalHistory));
    return true;
}

bool AdminDashboard::editUser(const std::string& id, const std::string& name, const std::string& email) {
    if (!sessionActive()) {
        return false;
    }
    const auto user = userManager_.findById(id);
    if (!user.has_value()) {
        return false;
    }
    return userManager_.updateUser(id, name, email, user.value()->getPasswordHash());
}

bool AdminDashboard::deleteUser(const std::string& id) {
    if (!sessionActive() || (activeAdminId_.has_value() && activeAdminId_.value() == id)) {
        return false;
    }
    return userManager_.deleteUser(id);
}

std::vector<Room> AdminDashboard::rooms() const {
    if (!sessionActive()) {
        return {};
    }
    return roomManager_.getAllRooms();
}

bool AdminDashboard::addRoom(const std::string& id, const std::string& type) {
    return sessionActive() && roomManager_.addRoom(id, type);
}

bool AdminDashboard::assignRoom(const std::string& roomId, const std::string& patientId) {
    return sessionActive() && roomManager_.assignRoom(roomId, patientId);
}

bool AdminDashboard::releaseRoom(const std::string& roomId) {
    return sessionActive() && roomManager_.releaseRoom(roomId);
}

std::vector<Appointment> AdminDashboard::appointments(const std::optional<std::string> doctorId,
                                                      const std::optional<AppointmentStatus> status,
                                                      const std::optional<std::string> startDateTime,
                                                      const std::optional<std::string> endDateTime) const {
    if (!sessionActive()) {
        return {};
    }
    return appointmentManager_.listAppointments(doctorId, std::nullopt, status, startDateTime, endDateTime);
}

bool AdminDashboard::cancelAppointment(const std::string& appointmentId) {
    return sessionActive() && appointmentManager_.cancelAppointment(appointmentId);
}

AdminDashboard::BillingOverview AdminDashboard::billingOverview() const {
    if (!sessionActive()) {
        return {};
    }
    return {billingManager_.getAllBills(), billingManager_.getSummary()};
}

bool AdminDashboard::setBillPaid(const std::string& billId, const bool isPaid) {
    return sessionActive() && billingManager_.markPaidStatus(billId, isPaid);
}

ReportManager::Summary AdminDashboard::reportSummary() const {
    if (!sessionActive()) {
        return {};
    }
    return reportManager_.getSummary();
}

std::vector<ReportManager::TimeBucketStat> AdminDashboard::reportDaily(const std::string& date) const {
    if (!sessionActive()) {
        return {};
    }
    return reportManager_.dailyAppointmentStats(date);
}

std::vector<ReportManager::TimeBucketStat> AdminDashboard::reportWeekly(const std::string& weekStartDate) const {
    if (!sessionActive()) {
        return {};
    }
    return reportManager_.weeklyAppointmentStats(weekStartDate);
}

bool AdminDashboard::sessionActive() const {
    return activeAdminId_.has_value();
}
