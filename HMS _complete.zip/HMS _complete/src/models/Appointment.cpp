#include "models/Appointment.h"

#include <utility>

std::string toString(const AppointmentStatus status) {
    switch (status) {
        case AppointmentStatus::Pending:
            return "Pending";
        case AppointmentStatus::Accepted:
            return "Accepted";
        case AppointmentStatus::Cancelled:
            return "Cancelled";
        case AppointmentStatus::Completed:
            return "Completed";
        default:
            return "Unknown";
    }
}

Appointment::Appointment(std::string id,
                         std::string patientId,
                         std::string doctorId,
                         std::string dateTime,
                         const AppointmentStatus status,
                         std::string notes)
    : id_(std::move(id)),
      patientId_(std::move(patientId)),
      doctorId_(std::move(doctorId)),
      dateTime_(std::move(dateTime)),
      status_(status),
      notes_(std::move(notes)) {}

const std::string& Appointment::getId() const {
    return id_;
}

const std::string& Appointment::getPatientId() const {
    return patientId_;
}

const std::string& Appointment::getDoctorId() const {
    return doctorId_;
}

const std::string& Appointment::getDateTime() const {
    return dateTime_;
}

AppointmentStatus Appointment::getStatus() const {
    return status_;
}

const std::string& Appointment::getNotes() const {
    return notes_;
}

void Appointment::setDateTime(const std::string& dateTime) {
    dateTime_ = dateTime;
}

void Appointment::setStatus(const AppointmentStatus status) {
    status_ = status;
}

void Appointment::setNotes(const std::string& notes) {
    notes_ = notes;
}
