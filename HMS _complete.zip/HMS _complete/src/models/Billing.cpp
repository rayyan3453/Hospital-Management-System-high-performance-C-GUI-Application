#include "models/Billing.h"

#include <utility>

Billing::Billing(std::string id,
                 std::string patientId,
                 const double amount,
                 const bool isPaid,
                 std::string date,
                 std::string itemizedList)
    : id_(std::move(id)),
      patientId_(std::move(patientId)),
      amount_(amount),
      isPaid_(isPaid),
      date_(std::move(date)),
      itemizedList_(std::move(itemizedList)) {}

const std::string& Billing::getId() const {
    return id_;
}

const std::string& Billing::getPatientId() const {
    return patientId_;
}

double Billing::getAmount() const {
    return amount_;
}

bool Billing::getIsPaid() const {
    return isPaid_;
}

const std::string& Billing::getDate() const {
    return date_;
}

const std::string& Billing::getItemizedList() const {
    return itemizedList_;
}

void Billing::setAmount(const double amount) {
    amount_ = amount;
}

void Billing::setIsPaid(const bool isPaid) {
    isPaid_ = isPaid;
}

void Billing::setDate(const std::string& date) {
    date_ = date;
}

void Billing::setItemizedList(const std::string& itemizedList) {
    itemizedList_ = itemizedList;
}
