#include "models/Admin.h"

#include <sstream>
#include <utility>

Admin::Admin(std::string id, std::string name, std::string email, std::string passwordHash)
    : User(std::move(id), std::move(name), std::move(email), std::move(passwordHash), UserRole::Admin) {}

std::string Admin::display() const {
    std::ostringstream oss;
    oss << "[Admin] ID: " << getId() << ", Name: " << getName() << ", Email: " << getEmail();
    return oss.str();
}

UserRole Admin::getRole() const {
    return getStoredRole();
}
