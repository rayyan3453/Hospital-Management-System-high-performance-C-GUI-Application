#include "models/MedicalRecord.h"

#include <utility>

MedicalRecord::MedicalRecord(std::string id,
                             std::string patientId,
                             std::string doctorId,
                             std::string diagnosis,
                             std::string prescription,
                             std::string date)
    : id_(std::move(id)),
      patientId_(std::move(patientId)),
      doctorId_(std::move(doctorId)),
      diagnosis_(std::move(diagnosis)),
      prescription_(std::move(prescription)),
      date_(std::move(date)) {}

const std::string& MedicalRecord::getId() const {
    return id_;
}

const std::string& MedicalRecord::getPatientId() const {
    return patientId_;
}

const std::string& MedicalRecord::getDoctorId() const {
    return doctorId_;
}

const std::string& MedicalRecord::getDiagnosis() const {
    return diagnosis_;
}

const std::string& MedicalRecord::getPrescription() const {
    return prescription_;
}

const std::string& MedicalRecord::getDate() const {
    return date_;
}

void MedicalRecord::setDiagnosis(const std::string& diagnosis) {
    diagnosis_ = diagnosis;
}

void MedicalRecord::setPrescription(const std::string& prescription) {
    prescription_ = prescription;
}

void MedicalRecord::setDate(const std::string& date) {
    date_ = date;
}
