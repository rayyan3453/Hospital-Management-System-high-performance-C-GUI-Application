#include "models/Patient.h"

#include <sstream>
#include <utility>

Patient::Patient(std::string id,
                 std::string name,
                 std::string email,
                 std::string passwordHash,
                 std::string dateOfBirth,
                 std::string medicalHistory)
    : User(std::move(id), std::move(name), std::move(email), std::move(passwordHash), UserRole::Patient),
      dateOfBirth_(std::move(dateOfBirth)),
      medicalHistory_(std::move(medicalHistory)) {}

std::string Patient::display() const {
    std::ostringstream oss;
    oss << "[Patient] ID: " << getId() << ", Name: " << getName() << ", Email: " << getEmail()
        << ", DOB: " << dateOfBirth_;
    return oss.str();
}

UserRole Patient::getRole() const {
    return getStoredRole();
}

const std::string& Patient::getDateOfBirth() const {
    return dateOfBirth_;
}

const std::string& Patient::getMedicalHistory() const {
    return medicalHistory_;
}

void Patient::setDateOfBirth(const std::string& dateOfBirth) {
    dateOfBirth_ = dateOfBirth;
}

void Patient::setMedicalHistory(const std::string& medicalHistory) {
    medicalHistory_ = medicalHistory;
}
