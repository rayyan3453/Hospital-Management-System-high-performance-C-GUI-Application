#include "models/Doctor.h"

#include <sstream>
#include <utility>

Doctor::Doctor(std::string id,
               std::string name,
               std::string email,
               std::string passwordHash,
               std::string specialization,
               std::string schedule)
    : User(std::move(id), std::move(name), std::move(email), std::move(passwordHash), UserRole::Doctor),
      specialization_(std::move(specialization)),
      schedule_(std::move(schedule)) {}

std::string Doctor::display() const {
    std::ostringstream oss;
    oss << "[Doctor] ID: " << getId() << ", Name: " << getName() << ", Email: " << getEmail()
        << ", Specialization: " << specialization_;
    return oss.str();
}

UserRole Doctor::getRole() const {
    return getStoredRole();
}

const std::string& Doctor::getSpecialization() const {
    return specialization_;
}

const std::string& Doctor::getSchedule() const {
    return schedule_;
}

void Doctor::setSpecialization(const std::string& specialization) {
    specialization_ = specialization;
}

void Doctor::setSchedule(const std::string& schedule) {
    schedule_ = schedule;
}
