#include "models/Room.h"

#include <utility>

Room::Room(std::string id, std::string type, const bool isOccupied, std::string assignedPatientId)
    : id_(std::move(id)),
      type_(std::move(type)),
      isOccupied_(isOccupied),
      assignedPatientId_(std::move(assignedPatientId)) {}

const std::string& Room::getId() const {
    return id_;
}

const std::string& Room::getType() const {
    return type_;
}

bool Room::getIsOccupied() const {
    return isOccupied_;
}

const std::string& Room::getAssignedPatientId() const {
    return assignedPatientId_;
}

void Room::setType(const std::string& type) {
    type_ = type;
}

void Room::setIsOccupied(const bool isOccupied) {
    isOccupied_ = isOccupied;
}

void Room::setAssignedPatientId(const std::string& assignedPatientId) {
    assignedPatientId_ = assignedPatientId;
}
