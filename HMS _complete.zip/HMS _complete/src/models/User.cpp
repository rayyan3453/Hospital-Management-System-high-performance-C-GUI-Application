#include "models/User.h"

#include <utility>

std::string toString(const UserRole role) {
    switch (role) {
        case UserRole::Admin:
            return "Admin";
        case UserRole::Doctor:
            return "Doctor";
        case UserRole::Patient:
            return "Patient";
        default:
            return "Unknown";
    }
}

User::User(std::string id, std::string name, std::string email, std::string passwordHash, const UserRole role)
    : id_(std::move(id)),
      name_(std::move(name)),
      email_(std::move(email)),
      passwordHash_(std::move(passwordHash)),
      role_(role) {}

const std::string& User::getId() const {
    return id_;
}

const std::string& User::getName() const {
    return name_;
}

const std::string& User::getEmail() const {
    return email_;
}

const std::string& User::getPasswordHash() const {
    return passwordHash_;
}

void User::setName(const std::string& name) {
    name_ = name;
}

void User::setEmail(const std::string& email) {
    email_ = email;
}

void User::setPasswordHash(const std::string& passwordHash) {
    passwordHash_ = passwordHash;
}

UserRole User::getStoredRole() const {
    return role_;
}
