#include "managers/AppointmentManager.h"
#include "managers/BillingManager.h"
#include "managers/MedicalRecordManager.h"
#include "managers/RoomManager.h"
#include "managers/UserManager.h"
#include "models/Doctor.h"
#include "models/Patient.h"
#include "ui/DoctorDashboard.h"
#include "ui/App.h"
#include "ui/PatientDashboard.h"
#include "utils/DateUtils.h"
#include "utils/HashUtils.h"

#include <filesystem>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
void require(const bool condition, const std::string& message) {
    if (!condition) {
        throw std::runtime_error("QA check failed: " + message);
    }
}

void prepareRuntimeData(const std::filesystem::path& sourceData, const std::filesystem::path& runtimeData) {
    std::error_code ec;
    std::filesystem::remove_all(runtimeData, ec);
    std::filesystem::create_directories(runtimeData, ec);
    if (ec) {
        throw std::runtime_error("Unable to create runtime data directory: " + runtimeData.string());
    }

    const std::vector<std::string> files = {
        "users.csv",
        "appointments.csv",
        "medical_records.csv",
        "billing.csv",
        "rooms.csv"
    };

    for (const auto& file : files) {
        const auto src = sourceData / file;
        const auto dst = runtimeData / file;
        std::filesystem::copy_file(src, dst, std::filesystem::copy_options::overwrite_existing, ec);
        if (ec) {
            throw std::runtime_error("Unable to copy seed file: " + file);
        }
    }
}

void loadManagers(const std::filesystem::path& runtimeData,
                  UserManager& userManager,
                  AppointmentManager& appointmentManager,
                  MedicalRecordManager& medicalRecordManager,
                  BillingManager& billingManager,
                  RoomManager& roomManager) {
    userManager.loadFromFile((runtimeData / "users.csv").string());
    appointmentManager.loadFromFile((runtimeData / "appointments.csv").string());
    medicalRecordManager.loadFromFile((runtimeData / "medical_records.csv").string());
    billingManager.loadFromFile((runtimeData / "billing.csv").string());
    roomManager.loadFromFile((runtimeData / "rooms.csv").string());
}

void runPhase11QaSuite() {
    const std::filesystem::path sourceData = std::filesystem::path("data");
    const std::filesystem::path runtimeData = sourceData / "qa_runtime";
    prepareRuntimeData(sourceData, runtimeData);

    UserManager userManager;
    AppointmentManager appointmentManager;
    MedicalRecordManager medicalRecordManager;
    BillingManager billingManager;
    RoomManager roomManager;
    loadManagers(runtimeData, userManager, appointmentManager, medicalRecordManager, billingManager, roomManager);

    // Auth checks for all roles.
    require(userManager.login("admin1@hms.local", "admin123", UserRole::Admin).has_value(), "admin login");
    require(userManager.login("doctor1@hms.local", "doctor123", UserRole::Doctor).has_value(), "doctor login");
    require(userManager.login("patient1@hms.local", "patient123", UserRole::Patient).has_value(), "patient login");
    require(!userManager.login("patient1@hms.local", "wrong-password", UserRole::Patient).has_value(), "bad password rejection");

    // User CRUD.
    const Patient tempPatient("pat_qa", "QA Patient", "qa.patient@hms.local",
                              HashUtils::hashPassword("patient123"), "2001-08-19", "N/A");
    userManager.addPatient(tempPatient);
    require(userManager.findById("pat_qa").has_value(), "added patient exists");
    require(userManager.updatePatientDetails("pat_qa", "2001-08-19", "Updated history"), "patient detail update");
    require(userManager.deleteUser("pat_qa"), "patient delete");
    require(!userManager.findById("pat_qa").has_value(), "patient deleted");

    // Appointment CRUD + filters.
    require(appointmentManager.scheduleAppointment("appt_qa_1", "pat_01", "doc_01", "2026-05-10 10:30", "QA booking"),
            "appointment create");
    require(appointmentManager.rescheduleAppointment("appt_qa_1", "2026-05-10 11:00"), "appointment reschedule");
    require(appointmentManager.updateStatus("appt_qa_1", AppointmentStatus::Accepted), "appointment accept");
    const auto filtered = appointmentManager.listAppointments("doc_01", std::nullopt, AppointmentStatus::Accepted,
                                                              "2026-05-10 00:00", "2026-05-10 23:59");
    require(!filtered.empty(), "appointment filter by doctor/status/date");
    require(appointmentManager.cancelAppointment("appt_qa_1"), "appointment cancel");

    // Medical record operations.
    require(medicalRecordManager.addRecord("mr_qa_1", "pat_01", "doc_01", "QA diagnosis", "QA Rx", "2026-05-01"),
            "medical record add");
    require(medicalRecordManager.editRecord("mr_qa_1", "QA diagnosis updated", "QA Rx updated", "2026-05-01"),
            "medical record edit");
    require(!medicalRecordManager.listByPatientId("pat_01").empty(), "medical record list by patient");

    // Billing operations.
    require(billingManager.createBill("bill_qa_1", "pat_01", 900.0, false, "2026-05-01", "Test|900"), "bill create");
    require(billingManager.markPaidStatus("bill_qa_1", true), "bill mark paid");
    const auto summary = billingManager.getSummary();
    require(summary.totalRevenue > 0.0, "billing summary revenue");

    // Room operations.
    require(roomManager.addRoom("room_qa_1", "General"), "room add");
    require(roomManager.assignRoom("room_qa_1", "pat_01"), "room assign");
    require(roomManager.releaseRoom("room_qa_1"), "room release");

    // Doctor dashboard flow.
    DoctorDashboard doctorDashboard(userManager, appointmentManager, medicalRecordManager);
    require(doctorDashboard.startSession("doc_01"), "doctor session start");
    const auto doctorProfile = doctorDashboard.myProfile();
    require(doctorProfile.has_value(), "doctor profile view");
    require(doctorDashboard.updateMyProfile("Dr Ayesha QA", "doctor1@hms.local", "Cardiology", "Mon-Fri 09:00-17:00",
                                            std::nullopt),
            "doctor profile update");
    const auto docSchedule = doctorDashboard.myWeeklySchedule("2026-05-04");
    require(!docSchedule.empty(), "doctor weekly schedule");
    doctorDashboard.logout();

    // Patient dashboard flow.
    PatientDashboard patientDashboard(userManager, appointmentManager, medicalRecordManager, billingManager);
    require(patientDashboard.startSession("pat_01"), "patient session start");
    const auto patientProfile = patientDashboard.myProfile();
    require(patientProfile.has_value(), "patient profile view");
    const auto specs = patientDashboard.availableSpecializations();
    require(!specs.empty(), "patient specialization list");
    const auto doctors = patientDashboard.doctorsBySpecialization(specs.front());
    require(!doctors.empty(), "patient doctor filter list");
    const auto slots = patientDashboard.availableSlotsForDoctor(doctors.front().id, "2026-05-11");
    require(!slots.empty(), "patient slot list");
    require(patientDashboard.bookAppointment("appt_qa_2", doctors.front().id, slots.front(), "QA patient booking"),
            "patient book appointment");
    require(!patientDashboard.myAppointments(true).empty(), "patient appointment listing");
    require(!patientDashboard.myMedicalHistory().empty(), "patient medical history read-only view");
    require(!patientDashboard.myInvoices().empty(), "patient invoices view");
    patientDashboard.logout();

    // Persistence check: reload and verify artifacts written to CSV.
    UserManager reloadedUsers;
    AppointmentManager reloadedAppointments;
    MedicalRecordManager reloadedRecords;
    BillingManager reloadedBilling;
    RoomManager reloadedRooms;
    loadManagers(runtimeData, reloadedUsers, reloadedAppointments, reloadedRecords, reloadedBilling, reloadedRooms);
    require(reloadedAppointments.findById("appt_qa_2").has_value(), "persisted appointment after reload");
    require(reloadedRecords.findById("mr_qa_1").has_value(), "persisted medical record after reload");
    require(reloadedBilling.findById("bill_qa_1").has_value(), "persisted billing after reload");
    require(reloadedRooms.findById("room_qa_1").has_value(), "persisted room after reload");
}
}  // namespace

int main(const int argc, char** argv) {
    if (argc > 1 && std::string(argv[1]) == "--phase11-check") {
        try {
            runPhase11QaSuite();
            std::cout << "Phase 11 QA suite passed." << std::endl;
            return 0;
        } catch (const std::exception& ex) {
            std::cerr << ex.what() << std::endl;
            return 1;
        }
    }

    try {
        // Resolve data path relative to the executable location
        std::filesystem::path exePath = std::filesystem::path(argv[0]).parent_path();
        std::string dataDir = (exePath / "data").string();
        if (!std::filesystem::exists(dataDir)) {
            dataDir = "data"; // fallback to CWD
        }
        App app;
        app.initialize(dataDir);
        app.run();
    } catch (const std::exception& ex) {
        std::cerr << "Error: " << ex.what() << std::endl;
        return 1;
    }
    return 0;
}
