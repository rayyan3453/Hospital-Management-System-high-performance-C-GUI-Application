#include "managers/BillingManager.h"

#include "utils/DateUtils.h"
#include "utils/FileParser.h"

#include <stdexcept>

namespace {
bool parseBool(const std::string& value) {
    return value == "1" || value == "true" || value == "TRUE" || value == "True";
}
}  // namespace

void BillingManager::loadFromFile(const std::string& path) {
    bills_.clear();
    const auto rows = FileParser::readCsvFile(path);
    if (rows.empty()) {
        persistencePath_ = path;
        return;
    }

    std::size_t startIndex = 0;
    if (!rows[0].empty() && rows[0][0] == "id") {
        startIndex = 1;
    }

    for (std::size_t i = startIndex; i < rows.size(); ++i) {
        const auto& row = rows[i];
        if (row.size() < 6) {
            throw std::runtime_error("Invalid billing.csv row width at row index " + std::to_string(i));
        }

        double amount = 0.0;
        try {
            amount = std::stod(row[2]);
        } catch (...) {
            throw std::runtime_error("Invalid billing amount at row index " + std::to_string(i));
        }

        bills_.emplace_back(row[0], row[1], amount, parseBool(row[3]), row[4], row[5]);
    }
    persistencePath_ = path;
}

void BillingManager::saveToFile(const std::string& path) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"id", "patientId", "amount", "isPaid", "date", "itemizedList"});
    for (const auto& bill : bills_) {
        rows.push_back({
            bill.getId(),
            bill.getPatientId(),
            std::to_string(bill.getAmount()),
            bill.getIsPaid() ? "1" : "0",
            bill.getDate(),
            bill.getItemizedList()
        });
    }
    FileParser::writeCsvFile(path, rows);
}

void BillingManager::setPersistencePath(const std::string& path) {
    persistencePath_ = path;
}

std::vector<Billing> BillingManager::getAllBills() const {
    return bills_;
}

std::optional<Billing> BillingManager::findById(const std::string& id) const {
    for (const auto& bill : bills_) {
        if (bill.getId() == id) {
            return bill;
        }
    }
    return std::nullopt;
}

std::vector<Billing> BillingManager::listByPatientId(const std::string& patientId) const {
    std::vector<Billing> out;
    for (const auto& bill : bills_) {
        if (bill.getPatientId() == patientId) {
            out.push_back(bill);
        }
    }
    return out;
}

bool BillingManager::createBill(const std::string& id,
                                const std::string& patientId,
                                const double amount,
                                const bool isPaid,
                                const std::string& date,
                                const std::string& itemizedList) {
    if (id.empty() || patientId.empty() || date.empty() || amount < 0.0) {
        return false;
    }
    if (idExists(id) || !DateUtils::isValidDate(date)) {
        return false;
    }

    bills_.emplace_back(id, patientId, amount, isPaid, date, itemizedList);
    autoSaveIfConfigured();
    return true;
}

bool BillingManager::updateBill(const std::string& id,
                                const double amount,
                                const std::string& date,
                                const std::string& itemizedList) {
    if (amount < 0.0 || date.empty() || !DateUtils::isValidDate(date)) {
        return false;
    }
    for (auto& bill : bills_) {
        if (bill.getId() == id) {
            bill.setAmount(amount);
            bill.setDate(date);
            bill.setItemizedList(itemizedList);
            autoSaveIfConfigured();
            return true;
        }
    }
    return false;
}

bool BillingManager::markPaidStatus(const std::string& id, const bool isPaid) {
    for (auto& bill : bills_) {
        if (bill.getId() == id) {
            bill.setIsPaid(isPaid);
            autoSaveIfConfigured();
            return true;
        }
    }
    return false;
}

BillingManager::Summary BillingManager::getSummary() const {
    Summary summary;
    for (const auto& bill : bills_) {
        if (bill.getIsPaid()) {
            summary.totalRevenue += bill.getAmount();
        } else {
            summary.outstandingAmount += bill.getAmount();
        }
    }
    return summary;
}

void BillingManager::autoSaveIfConfigured() const {
    if (!persistencePath_.empty()) {
        saveToFile(persistencePath_);
    }
}

bool BillingManager::idExists(const std::string& id) const {
    return findById(id).has_value();
}
