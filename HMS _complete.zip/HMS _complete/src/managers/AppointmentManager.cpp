#include "managers/AppointmentManager.h"

#include "utils/DateUtils.h"
#include "utils/FileParser.h"

#include <algorithm>
#include <stdexcept>

namespace {
AppointmentStatus parseStatus(const std::string& value) {
    if (value == "Pending") {
        return AppointmentStatus::Pending;
    }
    if (value == "Accepted") {
        return AppointmentStatus::Accepted;
    }
    if (value == "Cancelled") {
        return AppointmentStatus::Cancelled;
    }
    if (value == "Completed") {
        return AppointmentStatus::Completed;
    }
    throw std::runtime_error("Unsupported appointment status: " + value);
}
}  // namespace

void AppointmentManager::loadFromFile(const std::string& path) {
    appointments_.clear();
    const auto rows = FileParser::readCsvFile(path);
    if (rows.empty()) {
        persistencePath_ = path;
        return;
    }

    std::size_t startIndex = 0;
    if (!rows[0].empty() && rows[0][0] == "id") {
        startIndex = 1;
    }

    for (std::size_t i = startIndex; i < rows.size(); ++i) {
        const auto& row = rows[i];
        if (row.size() < 6) {
            throw std::runtime_error("Invalid appointments.csv row width at row index " + std::to_string(i));
        }
        appointments_.emplace_back(row[0], row[1], row[2], row[3], parseStatus(row[4]), row[5]);
    }
    persistencePath_ = path;
}

void AppointmentManager::saveToFile(const std::string& path) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"id", "patientId", "doctorId", "dateTime", "status", "notes"});

    for (const auto& appointment : appointments_) {
        rows.push_back({
            appointment.getId(),
            appointment.getPatientId(),
            appointment.getDoctorId(),
            appointment.getDateTime(),
            toString(appointment.getStatus()),
            appointment.getNotes()
        });
    }
    FileParser::writeCsvFile(path, rows);
}

void AppointmentManager::setPersistencePath(const std::string& path) {
    persistencePath_ = path;
}

std::vector<Appointment> AppointmentManager::getAllAppointments() const {
    return appointments_;
}

std::optional<Appointment> AppointmentManager::findById(const std::string& id) const {
    for (const auto& appointment : appointments_) {
        if (appointment.getId() == id) {
            return appointment;
        }
    }
    return std::nullopt;
}

bool AppointmentManager::scheduleAppointment(const std::string& id,
                                             const std::string& patientId,
                                             const std::string& doctorId,
                                             const std::string& dateTime,
                                             const std::string& notes) {
    if (id.empty() || patientId.empty() || doctorId.empty() || dateTime.empty()) {
        return false;
    }
    if (!DateUtils::isValidDateTime(dateTime)) {
        return false;
    }
    if (idExists(id) || doctorSlotTaken(doctorId, dateTime)) {
        return false;
    }

    appointments_.emplace_back(id, patientId, doctorId, dateTime, AppointmentStatus::Pending, notes);
    autoSaveIfConfigured();
    return true;
}

bool AppointmentManager::cancelAppointment(const std::string& id) {
    return updateStatus(id, AppointmentStatus::Cancelled);
}

bool AppointmentManager::rescheduleAppointment(const std::string& id, const std::string& newDateTime) {
    if (!DateUtils::isValidDateTime(newDateTime)) {
        return false;
    }

    for (auto& appointment : appointments_) {
        if (appointment.getId() != id) {
            continue;
        }
        if (appointment.getStatus() == AppointmentStatus::Cancelled ||
            appointment.getStatus() == AppointmentStatus::Completed) {
            return false;
        }
        if (doctorSlotTaken(appointment.getDoctorId(), newDateTime, id)) {
            return false;
        }
        appointment.setDateTime(newDateTime);
        autoSaveIfConfigured();
        return true;
    }
    return false;
}

bool AppointmentManager::updateStatus(const std::string& id, const AppointmentStatus status) {
    for (auto& appointment : appointments_) {
        if (appointment.getId() != id) {
            continue;
        }
        appointment.setStatus(status);
        autoSaveIfConfigured();
        return true;
    }
    return false;
}

std::vector<Appointment> AppointmentManager::listAppointments(
    const std::optional<std::string> doctorId,
    const std::optional<std::string> patientId,
    const std::optional<AppointmentStatus> status,
    const std::optional<std::string> startDateTime,
    const std::optional<std::string> endDateTime) const {
    std::vector<Appointment> out;
    for (const auto& appointment : appointments_) {
        if (doctorId.has_value() && appointment.getDoctorId() != doctorId.value()) {
            continue;
        }
        if (patientId.has_value() && appointment.getPatientId() != patientId.value()) {
            continue;
        }
        if (status.has_value() && appointment.getStatus() != status.value()) {
            continue;
        }
        if (startDateTime.has_value() && endDateTime.has_value()) {
            if (!DateUtils::isDateTimeInRange(appointment.getDateTime(), startDateTime.value(), endDateTime.value())) {
                continue;
            }
        } else if (startDateTime.has_value()) {
            if (DateUtils::compareDateTime(appointment.getDateTime(), startDateTime.value()) < 0) {
                continue;
            }
        } else if (endDateTime.has_value()) {
            if (DateUtils::compareDateTime(appointment.getDateTime(), endDateTime.value()) > 0) {
                continue;
            }
        }
        out.push_back(appointment);
    }
    return out;
}

void AppointmentManager::autoSaveIfConfigured() const {
    if (!persistencePath_.empty()) {
        saveToFile(persistencePath_);
    }
}

bool AppointmentManager::idExists(const std::string& id) const {
    return findById(id).has_value();
}

bool AppointmentManager::doctorSlotTaken(const std::string& doctorId,
                                         const std::string& dateTime,
                                         const std::string& excludeId) const {
    for (const auto& appointment : appointments_) {
        if (!excludeId.empty() && appointment.getId() == excludeId) {
            continue;
        }
        if (appointment.getDoctorId() != doctorId) {
            continue;
        }
        if (appointment.getDateTime() != dateTime) {
            continue;
        }
        if (appointment.getStatus() == AppointmentStatus::Cancelled) {
            continue;
        }
        return true;
    }
    return false;
}
