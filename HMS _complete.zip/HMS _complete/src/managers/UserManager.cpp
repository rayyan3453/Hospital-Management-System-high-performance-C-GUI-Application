#include "managers/UserManager.h"

#include "models/Admin.h"
#include "models/Doctor.h"
#include "models/Patient.h"
#include "utils/FileParser.h"
#include "utils/HashUtils.h"

#include <algorithm>
#include <cctype>
#include <stdexcept>
#include <utility>

namespace {
std::string toLowerCopy(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](const unsigned char ch) {
        return static_cast<char>(std::tolower(ch));
    });
    return value;
}

UserRole parseRole(const std::string& value) {
    const std::string normalized = toLowerCopy(value);
    if (normalized == "admin") {
        return UserRole::Admin;
    }
    if (normalized == "doctor") {
        return UserRole::Doctor;
    }
    if (normalized == "patient") {
        return UserRole::Patient;
    }
    throw std::runtime_error("Unsupported user role: " + value);
}
}  // namespace

void UserManager::loadFromFile(const std::string& path) {
    users_.clear();
    const auto rows = FileParser::readCsvFile(path);
    if (rows.empty()) {
        persistencePath_ = path;
        return;
    }

    std::size_t startIndex = 0;
    if (!rows[0].empty() && toLowerCopy(rows[0][0]) == "id") {
        startIndex = 1;
    }

    for (std::size_t i = startIndex; i < rows.size(); ++i) {
        const auto& row = rows[i];
        if (row.size() < 7) {
            throw std::runtime_error("Invalid users.csv row width at row index " + std::to_string(i));
        }

        const UserRole role = parseRole(row[4]);
        if (role == UserRole::Admin) {
            users_.push_back(std::make_unique<Admin>(row[0], row[1], row[2], row[3]));
        } else if (role == UserRole::Doctor) {
            users_.push_back(std::make_unique<Doctor>(row[0], row[1], row[2], row[3], row[5], row[6]));
        } else {
            users_.push_back(std::make_unique<Patient>(row[0], row[1], row[2], row[3], row[5], row[6]));
        }
    }
    persistencePath_ = path;
}

void UserManager::saveToFile(const std::string& path) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"id", "name", "email", "passwordHash", "role", "extra1", "extra2"});

    for (const auto& user : users_) {
        std::vector<std::string> row = {
            user->getId(),
            user->getName(),
            user->getEmail(),
            user->getPasswordHash(),
            toString(user->getRole()),
            "",
            ""
        };

        if (user->getRole() == UserRole::Doctor) {
            const auto* doctor = dynamic_cast<const Doctor*>(user.get());
            if (doctor != nullptr) {
                row[5] = doctor->getSpecialization();
                row[6] = doctor->getSchedule();
            }
        } else if (user->getRole() == UserRole::Patient) {
            const auto* patient = dynamic_cast<const Patient*>(user.get());
            if (patient != nullptr) {
                row[5] = patient->getDateOfBirth();
                row[6] = patient->getMedicalHistory();
            }
        }
        rows.push_back(std::move(row));
    }

    FileParser::writeCsvFile(path, rows);
}

void UserManager::setPersistencePath(const std::string& path) {
    persistencePath_ = path;
}

std::vector<const User*> UserManager::getAllUsers() const {
    std::vector<const User*> out;
    out.reserve(users_.size());
    for (const auto& user : users_) {
        out.push_back(user.get());
    }
    return out;
}

std::optional<const User*> UserManager::findById(const std::string& id) const {
    for (const auto& user : users_) {
        if (user->getId() == id) {
            return user.get();
        }
    }
    return std::nullopt;
}

std::optional<const User*> UserManager::findByEmail(const std::string& email) const {
    const std::string normalized = toLowerCopy(email);
    for (const auto& user : users_) {
        if (toLowerCopy(user->getEmail()) == normalized) {
            return user.get();
        }
    }
    return std::nullopt;
}

std::vector<const User*> UserManager::searchUsers(const std::string& nameQuery,
                                                  const std::optional<UserRole> roleFilter) const {
    const std::string query = toLowerCopy(nameQuery);
    std::vector<const User*> out;

    for (const auto& user : users_) {
        if (roleFilter.has_value() && user->getRole() != roleFilter.value()) {
            continue;
        }
        if (!query.empty() && toLowerCopy(user->getName()).find(query) == std::string::npos) {
            continue;
        }
        out.push_back(user.get());
    }
    return out;
}

std::optional<const User*> UserManager::login(const std::string& email,
                                              const std::string& plainPassword,
                                              const UserRole role) const {
    const auto byEmail = findByEmail(email);
    if (!byEmail.has_value()) {
        return std::nullopt;
    }
    const User* user = byEmail.value();
    if (user->getRole() != role) {
        return std::nullopt;
    }
    if (!HashUtils::verifyPassword(plainPassword, user->getPasswordHash())) {
        return std::nullopt;
    }
    return user;
}

void UserManager::addAdmin(const Admin& admin) {
    if (idExists(admin.getId())) {
        throw std::runtime_error("Duplicate user id: " + admin.getId());
    }
    if (emailExists(admin.getEmail())) {
        throw std::runtime_error("Duplicate email: " + admin.getEmail());
    }
    users_.push_back(std::make_unique<Admin>(admin));
    autoSaveIfConfigured();
}

void UserManager::addDoctor(const Doctor& doctor) {
    if (idExists(doctor.getId())) {
        throw std::runtime_error("Duplicate user id: " + doctor.getId());
    }
    if (emailExists(doctor.getEmail())) {
        throw std::runtime_error("Duplicate email: " + doctor.getEmail());
    }
    users_.push_back(std::make_unique<Doctor>(doctor));
    autoSaveIfConfigured();
}

void UserManager::addPatient(const Patient& patient) {
    if (idExists(patient.getId())) {
        throw std::runtime_error("Duplicate user id: " + patient.getId());
    }
    if (emailExists(patient.getEmail())) {
        throw std::runtime_error("Duplicate email: " + patient.getEmail());
    }
    users_.push_back(std::make_unique<Patient>(patient));
    autoSaveIfConfigured();
}

bool UserManager::updateUser(const std::string& id,
                             const std::string& name,
                             const std::string& email,
                             const std::string& passwordHash) {
    if (emailExists(email, id)) {
        throw std::runtime_error("Duplicate email: " + email);
    }

    for (const auto& user : users_) {
        if (user->getId() == id) {
            user->setName(name);
            user->setEmail(email);
            user->setPasswordHash(passwordHash);
            autoSaveIfConfigured();
            return true;
        }
    }
    return false;
}

bool UserManager::updateDoctorDetails(const std::string& id,
                                      const std::string& specialization,
                                      const std::string& schedule) {
    for (const auto& user : users_) {
        if (user->getId() != id) {
            continue;
        }
        auto* doctor = dynamic_cast<Doctor*>(user.get());
        if (doctor == nullptr) {
            return false;
        }
        doctor->setSpecialization(specialization);
        doctor->setSchedule(schedule);
        autoSaveIfConfigured();
        return true;
    }
    return false;
}

bool UserManager::updatePatientDetails(const std::string& id,
                                       const std::string& dateOfBirth,
                                       const std::string& medicalHistory) {
    for (const auto& user : users_) {
        if (user->getId() != id) {
            continue;
        }
        auto* patient = dynamic_cast<Patient*>(user.get());
        if (patient == nullptr) {
            return false;
        }
        patient->setDateOfBirth(dateOfBirth);
        patient->setMedicalHistory(medicalHistory);
        autoSaveIfConfigured();
        return true;
    }
    return false;
}

bool UserManager::deleteUser(const std::string& id) {
    const auto it = std::remove_if(users_.begin(), users_.end(), [&](const std::unique_ptr<User>& user) {
        return user->getId() == id;
    });
    if (it == users_.end()) {
        return false;
    }

    users_.erase(it, users_.end());
    autoSaveIfConfigured();
    return true;
}

void UserManager::autoSaveIfConfigured() const {
    if (!persistencePath_.empty()) {
        saveToFile(persistencePath_);
    }
}

bool UserManager::idExists(const std::string& id) const {
    return findById(id).has_value();
}

bool UserManager::emailExists(const std::string& email, const std::string& excludeId) const {
    const std::string normalized = toLowerCopy(email);
    for (const auto& user : users_) {
        if (!excludeId.empty() && user->getId() == excludeId) {
            continue;
        }
        if (toLowerCopy(user->getEmail()) == normalized) {
            return true;
        }
    }
    return false;
}
