#include "managers/MedicalRecordManager.h"

#include "utils/DateUtils.h"
#include "utils/FileParser.h"

#include <stdexcept>

void MedicalRecordManager::loadFromFile(const std::string& path) {
    records_.clear();
    const auto rows = FileParser::readCsvFile(path);
    if (rows.empty()) {
        persistencePath_ = path;
        return;
    }

    std::size_t startIndex = 0;
    if (!rows[0].empty() && rows[0][0] == "id") {
        startIndex = 1;
    }

    for (std::size_t i = startIndex; i < rows.size(); ++i) {
        const auto& row = rows[i];
        if (row.size() < 6) {
            throw std::runtime_error("Invalid medical_records.csv row width at row index " + std::to_string(i));
        }
        records_.emplace_back(row[0], row[1], row[2], row[3], row[4], row[5]);
    }
    persistencePath_ = path;
}

void MedicalRecordManager::saveToFile(const std::string& path) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"id", "patientId", "doctorId", "diagnosis", "prescription", "date"});
    for (const auto& record : records_) {
        rows.push_back({
            record.getId(),
            record.getPatientId(),
            record.getDoctorId(),
            record.getDiagnosis(),
            record.getPrescription(),
            record.getDate()
        });
    }
    FileParser::writeCsvFile(path, rows);
}

void MedicalRecordManager::setPersistencePath(const std::string& path) {
    persistencePath_ = path;
}

std::vector<MedicalRecord> MedicalRecordManager::getAllRecords() const {
    return records_;
}

std::optional<MedicalRecord> MedicalRecordManager::findById(const std::string& id) const {
    for (const auto& record : records_) {
        if (record.getId() == id) {
            return record;
        }
    }
    return std::nullopt;
}

std::vector<MedicalRecord> MedicalRecordManager::listByPatientId(const std::string& patientId) const {
    std::vector<MedicalRecord> out;
    for (const auto& record : records_) {
        if (record.getPatientId() == patientId) {
            out.push_back(record);
        }
    }
    return out;
}

std::vector<MedicalRecord> MedicalRecordManager::listByDoctorId(const std::string& doctorId) const {
    std::vector<MedicalRecord> out;
    for (const auto& record : records_) {
        if (record.getDoctorId() == doctorId) {
            out.push_back(record);
        }
    }
    return out;
}

bool MedicalRecordManager::addRecord(const std::string& id,
                                     const std::string& patientId,
                                     const std::string& doctorId,
                                     const std::string& diagnosis,
                                     const std::string& prescription,
                                     const std::string& date) {
    if (id.empty() || patientId.empty() || doctorId.empty() || diagnosis.empty() || date.empty()) {
        return false;
    }
    if (idExists(id) || !DateUtils::isValidDate(date)) {
        return false;
    }

    records_.emplace_back(id, patientId, doctorId, diagnosis, prescription, date);
    autoSaveIfConfigured();
    return true;
}

bool MedicalRecordManager::editRecord(const std::string& id,
                                      const std::string& diagnosis,
                                      const std::string& prescription,
                                      const std::string& date) {
    if (diagnosis.empty() || date.empty() || !DateUtils::isValidDate(date)) {
        return false;
    }

    for (auto& record : records_) {
        if (record.getId() == id) {
            record.setDiagnosis(diagnosis);
            record.setPrescription(prescription);
            record.setDate(date);
            autoSaveIfConfigured();
            return true;
        }
    }
    return false;
}

void MedicalRecordManager::autoSaveIfConfigured() const {
    if (!persistencePath_.empty()) {
        saveToFile(persistencePath_);
    }
}

bool MedicalRecordManager::idExists(const std::string& id) const {
    return findById(id).has_value();
}
