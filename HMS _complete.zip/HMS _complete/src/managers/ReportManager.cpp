#include "managers/ReportManager.h"

#include "utils/DateUtils.h"

#include <iomanip>
#include <sstream>

ReportManager::ReportManager(const UserManager& userManager, const AppointmentManager& appointmentManager)
    : userManager_(userManager), appointmentManager_(appointmentManager) {}

ReportManager::Summary ReportManager::getSummary() const {
    Summary summary;

    for (const User* user : userManager_.getAllUsers()) {
        if (user->getRole() == UserRole::Patient) {
            ++summary.patientCount;
        } else if (user->getRole() == UserRole::Doctor) {
            ++summary.doctorCount;
        } else if (user->getRole() == UserRole::Admin) {
            ++summary.adminCount;
        }
    }

    for (const auto& appointment : appointmentManager_.getAllAppointments()) {
        ++summary.totalAppointments;
        if (appointment.getStatus() == AppointmentStatus::Pending ||
            appointment.getStatus() == AppointmentStatus::Accepted) {
            ++summary.pendingAppointments;
        } else if (appointment.getStatus() == AppointmentStatus::Completed) {
            ++summary.completedAppointments;
        } else if (appointment.getStatus() == AppointmentStatus::Cancelled) {
            ++summary.cancelledAppointments;
        }
    }

    return summary;
}

std::vector<ReportManager::TimeBucketStat> ReportManager::weeklyAppointmentStats(const std::string& weekStartDate) const {
    std::vector<TimeBucketStat> stats;
    stats.reserve(7);

    for (int dayOffset = 0; dayOffset < 7; ++dayOffset) {
        const auto day = DateUtils::addDays(weekStartDate, dayOffset);
        if (!day.has_value()) {
            continue;
        }

        const std::string start = day.value() + " 00:00";
        const std::string end = day.value() + " 23:59";
        const int count = static_cast<int>(
            appointmentManager_.listAppointments(std::nullopt, std::nullopt, std::nullopt, start, end).size());
        stats.push_back({day.value(), count});
    }

    return stats;
}

std::vector<ReportManager::TimeBucketStat> ReportManager::dailyAppointmentStats(const std::string& date) const {
    std::vector<TimeBucketStat> stats;
    stats.reserve(24);

    for (int hour = 0; hour < 24; ++hour) {
        std::ostringstream start;
        std::ostringstream end;
        start << date << ' ' << std::setfill('0') << std::setw(2) << hour << ":00";
        end << date << ' ' << std::setfill('0') << std::setw(2) << hour << ":59";

        const int count = static_cast<int>(
            appointmentManager_.listAppointments(std::nullopt, std::nullopt, std::nullopt, start.str(), end.str()).size());

        std::ostringstream label;
        label << std::setfill('0') << std::setw(2) << hour << ":00";
        stats.push_back({label.str(), count});
    }

    return stats;
}
