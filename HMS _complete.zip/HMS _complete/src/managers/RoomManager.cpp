#include "managers/RoomManager.h"

#include "utils/FileParser.h"

namespace {
bool parseBool(const std::string& value) {
    return value == "1" || value == "true" || value == "TRUE" || value == "True";
}
}  // namespace

void RoomManager::loadFromFile(const std::string& path) {
    rooms_.clear();
    const auto rows = FileParser::readCsvFile(path);
    if (rows.empty()) {
        persistencePath_ = path;
        return;
    }

    std::size_t startIndex = 0;
    if (!rows[0].empty() && rows[0][0] == "id") {
        startIndex = 1;
    }

    for (std::size_t i = startIndex; i < rows.size(); ++i) {
        const auto& row = rows[i];
        if (row.size() < 4) {
            continue;
        }
        rooms_.emplace_back(row[0], row[1], parseBool(row[2]), row[3]);
    }
    persistencePath_ = path;
}

void RoomManager::saveToFile(const std::string& path) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"id", "type", "isOccupied", "assignedPatientId"});
    for (const auto& room : rooms_) {
        rows.push_back({
            room.getId(),
            room.getType(),
            room.getIsOccupied() ? "1" : "0",
            room.getAssignedPatientId()
        });
    }
    FileParser::writeCsvFile(path, rows);
}

void RoomManager::setPersistencePath(const std::string& path) {
    persistencePath_ = path;
}

std::vector<Room> RoomManager::getAllRooms() const {
    return rooms_;
}

std::optional<Room> RoomManager::findById(const std::string& id) const {
    for (const auto& room : rooms_) {
        if (room.getId() == id) {
            return room;
        }
    }
    return std::nullopt;
}

std::vector<Room> RoomManager::listAvailableRooms() const {
    std::vector<Room> available;
    for (const auto& room : rooms_) {
        if (!room.getIsOccupied()) {
            available.push_back(room);
        }
    }
    return available;
}

bool RoomManager::addRoom(const std::string& id, const std::string& type) {
    if (id.empty() || type.empty() || idExists(id)) {
        return false;
    }
    rooms_.emplace_back(id, type, false, "");
    autoSaveIfConfigured();
    return true;
}

bool RoomManager::assignRoom(const std::string& roomId, const std::string& patientId) {
    if (patientId.empty() || patientAlreadyAssigned(patientId)) {
        return false;
    }
    for (auto& room : rooms_) {
        if (room.getId() == roomId) {
            if (room.getIsOccupied()) {
                return false;
            }
            room.setIsOccupied(true);
            room.setAssignedPatientId(patientId);
            autoSaveIfConfigured();
            return true;
        }
    }
    return false;
}

bool RoomManager::releaseRoom(const std::string& roomId) {
    for (auto& room : rooms_) {
        if (room.getId() == roomId) {
            if (!room.getIsOccupied()) {
                return false;
            }
            room.setIsOccupied(false);
            room.setAssignedPatientId("");
            autoSaveIfConfigured();
            return true;
        }
    }
    return false;
}

void RoomManager::autoSaveIfConfigured() const {
    if (!persistencePath_.empty()) {
        saveToFile(persistencePath_);
    }
}

bool RoomManager::idExists(const std::string& id) const {
    return findById(id).has_value();
}

bool RoomManager::patientAlreadyAssigned(const std::string& patientId) const {
    for (const auto& room : rooms_) {
        if (room.getIsOccupied() && room.getAssignedPatientId() == patientId) {
            return true;
        }
    }
    return false;
}
