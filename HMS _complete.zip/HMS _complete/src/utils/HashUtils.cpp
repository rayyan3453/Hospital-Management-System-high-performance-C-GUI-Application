#include "utils/HashUtils.h"

#include <cstdint>

namespace HashUtils {
namespace {
std::uint64_t djb2(const std::string& value) {
    std::uint64_t hash = 5381U;
    for (const unsigned char ch : value) {
        hash = ((hash << 5U) + hash) + ch;
    }
    return hash;
}
}  // namespace

std::string hashPassword(const std::string& value) {
    return std::to_string(djb2(value));
}

bool verifyPassword(const std::string& plainText, const std::string& hashed) {
    return hashPassword(plainText) == hashed;
}
}  // namespace HashUtils
