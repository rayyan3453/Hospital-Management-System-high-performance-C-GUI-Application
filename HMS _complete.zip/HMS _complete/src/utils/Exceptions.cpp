#include "utils/Exceptions.h"

AuthException::AuthException(const std::string& message)
    : std::runtime_error(message) {}

NotFoundException::NotFoundException(const std::string& message)
    : std::runtime_error(message) {}
