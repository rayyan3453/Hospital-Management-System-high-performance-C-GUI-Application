#include "utils/FileParser.h"

#include <fstream>
#include <sstream>
#include <stdexcept>

namespace FileParser {
namespace {
std::string escapeCsvField(const std::string& value) {
    bool needsQuotes = false;
    std::string escaped;
    escaped.reserve(value.size());

    for (const char ch : value) {
        if (ch == '"') {
            escaped.push_back('"');
            escaped.push_back('"');
            needsQuotes = true;
            continue;
        }
        if (ch == ',' || ch == '\n' || ch == '\r') {
            needsQuotes = true;
        }
        escaped.push_back(ch);
    }

    if (needsQuotes) {
        return "\"" + escaped + "\"";
    }
    return escaped;
}
}  // namespace

std::vector<std::string> parseCsvRow(const std::string& line) {
    std::vector<std::string> fields;
    std::string current;
    bool insideQuotes = false;

    for (std::size_t i = 0; i < line.size(); ++i) {
        const char ch = line[i];
        if (insideQuotes) {
            if (ch == '"') {
                if ((i + 1U) < line.size() && line[i + 1U] == '"') {
                    current.push_back('"');
                    ++i;
                } else {
                    insideQuotes = false;
                }
            } else {
                current.push_back(ch);
            }
        } else {
            if (ch == ',') {
                fields.push_back(current);
                current.clear();
            } else if (ch == '"') {
                insideQuotes = true;
            } else {
                current.push_back(ch);
            }
        }
    }
    fields.push_back(current);
    return fields;
}

std::string toCsvRow(const std::vector<std::string>& fields) {
    std::ostringstream oss;
    for (std::size_t i = 0; i < fields.size(); ++i) {
        if (i != 0U) {
            oss << ',';
        }
        oss << escapeCsvField(fields[i]);
    }
    return oss.str();
}

std::vector<std::vector<std::string>> readCsvFile(const std::string& path) {
    std::ifstream input(path);
    if (!input.is_open()) {
        throw std::runtime_error("Unable to open CSV file for reading: " + path);
    }

    std::vector<std::vector<std::string>> rows;
    std::string line;
    while (std::getline(input, line)) {
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }
        rows.push_back(parseCsvRow(line));
    }
    return rows;
}

void writeCsvFile(const std::string& path, const std::vector<std::vector<std::string>>& rows) {
    std::ofstream output(path, std::ios::trunc);
    if (!output.is_open()) {
        throw std::runtime_error("Unable to open CSV file for writing: " + path);
    }

    for (std::size_t i = 0; i < rows.size(); ++i) {
        output << toCsvRow(rows[i]);
        if ((i + 1U) < rows.size()) {
            output << '\n';
        }
    }
}
}  // namespace FileParser
