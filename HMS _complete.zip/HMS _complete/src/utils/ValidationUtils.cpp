#include "utils/ValidationUtils.h"

#include <algorithm>
#include <cctype>
#include <regex>

namespace ValidationUtils {
bool isRequiredFilled(const std::string& value) {
    return std::any_of(value.begin(), value.end(), [](const unsigned char ch) {
        return !std::isspace(ch);
    });
}

bool isValidEmail(const std::string& email) {
    static const std::regex pattern(R"(^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$)");
    return std::regex_match(email, pattern);
}

bool isStrongEnoughPassword(const std::string& password, const int minLength) {
    return static_cast<int>(password.size()) >= minLength;
}

bool isValidId(const std::string& id) {
    static const std::regex pattern(R"(^[A-Za-z0-9_-]+$)");
    return !id.empty() && std::regex_match(id, pattern);
}
}  // namespace ValidationUtils
