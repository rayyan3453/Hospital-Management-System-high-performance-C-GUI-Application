#include "utils/DateUtils.h"

#include <array>
#include <ctime>
#include <iomanip>
#include <sstream>

namespace DateUtils {
namespace {
bool isLeapYear(const int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int daysInMonth(const int year, const int month) {
    static constexpr std::array<int, 12> baseDays = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month == 2) {
        return isLeapYear(year) ? 29 : 28;
    }
    return baseDays[static_cast<std::size_t>(month - 1)];
}

bool parseIntSafe(const std::string& value, int& out) {
    try {
        std::size_t pos = 0;
        out = std::stoi(value, &pos);
        return pos == value.size();
    } catch (...) {
        return false;
    }
}

bool parseDateParts(const std::string& value, int& year, int& month, int& day) {
    if (value.size() != 10 || value[4] != '-' || value[7] != '-') {
        return false;
    }
    if (!parseIntSafe(value.substr(0, 4), year) ||
        !parseIntSafe(value.substr(5, 2), month) ||
        !parseIntSafe(value.substr(8, 2), day)) {
        return false;
    }
    if (year < 1900 || month < 1 || month > 12) {
        return false;
    }
    return day >= 1 && day <= daysInMonth(year, month);
}

bool parseDateTimeParts(const std::string& value, int& year, int& month, int& day, int& hour, int& minute) {
    if (value.size() != 16 || value[10] != ' ' || value[13] != ':') {
        return false;
    }
    if (!parseDateParts(value.substr(0, 10), year, month, day)) {
        return false;
    }
    if (!parseIntSafe(value.substr(11, 2), hour) || !parseIntSafe(value.substr(14, 2), minute)) {
        return false;
    }
    return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59;
}

std::string toDateString(const int year, const int month, const int day) {
    std::ostringstream oss;
    oss << std::setfill('0')
        << std::setw(4) << year << '-'
        << std::setw(2) << month << '-'
        << std::setw(2) << day;
    return oss.str();
}

std::time_t toTimeT(const int year, const int month, const int day) {
    std::tm tmValue = {};
    tmValue.tm_year = year - 1900;
    tmValue.tm_mon = month - 1;
    tmValue.tm_mday = day;
    tmValue.tm_hour = 12;
    tmValue.tm_min = 0;
    tmValue.tm_sec = 0;
    tmValue.tm_isdst = -1;
    return std::mktime(&tmValue);
}
}  // namespace

bool isValidDate(const std::string& value) {
    int year = 0;
    int month = 0;
    int day = 0;
    return parseDateParts(value, year, month, day);
}

bool isValidDateTime(const std::string& value) {
    int year = 0;
    int month = 0;
    int day = 0;
    int hour = 0;
    int minute = 0;
    return parseDateTimeParts(value, year, month, day, hour, minute);
}

int compareDateTime(const std::string& lhs, const std::string& rhs) {
    if (!isValidDateTime(lhs) || !isValidDateTime(rhs)) {
        return lhs.compare(rhs) < 0 ? -1 : (lhs.compare(rhs) > 0 ? 1 : 0);
    }
    if (lhs < rhs) {
        return -1;
    }
    if (lhs > rhs) {
        return 1;
    }
    return 0;
}

bool isDateTimeInRange(const std::string& target, const std::string& start, const std::string& end) {
    if (!isValidDateTime(target) || !isValidDateTime(start) || !isValidDateTime(end)) {
        return false;
    }
    return compareDateTime(target, start) >= 0 && compareDateTime(target, end) <= 0;
}

std::vector<std::string> generateDaySlots(const std::string& date, const int startHour, const int endHour) {
    std::vector<std::string> slots;
    if (!isValidDate(date) || startHour < 0 || endHour > 24 || startHour >= endHour) {
        return slots;
    }

    for (int hour = startHour; hour < endHour; ++hour) {
        for (int minute : {0, 30}) {
            std::ostringstream oss;
            oss << date << ' ' << std::setfill('0') << std::setw(2) << hour << ':'
                << std::setw(2) << minute;
            slots.push_back(oss.str());
        }
    }
    return slots;
}

std::optional<std::string> addDays(const std::string& date, const int days) {
    int year = 0;
    int month = 0;
    int day = 0;
    if (!parseDateParts(date, year, month, day)) {
        return std::nullopt;
    }

    const std::time_t base = toTimeT(year, month, day);
    if (base == static_cast<std::time_t>(-1)) {
        return std::nullopt;
    }

    constexpr std::time_t secondsPerDay = 24 * 60 * 60;
    const std::time_t updated = base + static_cast<std::time_t>(days) * secondsPerDay;
    std::tm* tmPtr = std::localtime(&updated);
    if (tmPtr == nullptr) {
        return std::nullopt;
    }
    return toDateString(tmPtr->tm_year + 1900, tmPtr->tm_mon + 1, tmPtr->tm_mday);
}

std::string currentDateTime() {
    const std::time_t now = std::time(nullptr);
    std::tm* tmPtr = std::localtime(&now);
    if (tmPtr == nullptr) {
        return "1970-01-01 00:00";
    }

    std::ostringstream oss;
    oss << std::setfill('0')
        << std::setw(4) << (tmPtr->tm_year + 1900) << '-'
        << std::setw(2) << (tmPtr->tm_mon + 1) << '-'
        << std::setw(2) << tmPtr->tm_mday << ' '
        << std::setw(2) << tmPtr->tm_hour << ':'
        << std::setw(2) << tmPtr->tm_min;
    return oss.str();
}
}  // namespace DateUtils
