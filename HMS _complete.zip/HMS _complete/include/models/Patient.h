#pragma once

#include "models/User.h"

/**
 * @brief Patient user with demographic and medical-history metadata.
 */
class Patient final : public User {
public:
    /**
     * @brief Constructs a patient user.
     * @param id User identifier.
     * @param name Full name.
     * @param email Email address.
     * @param passwordHash Hashed password.
     * @param dateOfBirth Birth date string.
     * @param medicalHistory Medical history summary.
     */
    Patient(std::string id,
            std::string name,
            std::string email,
            std::string passwordHash,
            std::string dateOfBirth,
            std::string medicalHistory);

    /**
     * @brief Displays patient details.
     * @return Display text.
     */
    std::string display() const override;

    /**
     * @brief Returns role.
     * @return UserRole::Patient.
     */
    UserRole getRole() const override;

    /**
     * @brief Gets date of birth.
     * @return Birth date string.
     */
    const std::string& getDateOfBirth() const;

    /**
     * @brief Gets medical history summary.
     * @return Medical history text.
     */
    const std::string& getMedicalHistory() const;

    /**
     * @brief Sets date of birth.
     * @param dateOfBirth Updated birth date.
     */
    void setDateOfBirth(const std::string& dateOfBirth);

    /**
     * @brief Sets medical history summary.
     * @param medicalHistory Updated medical history.
     */
    void setMedicalHistory(const std::string& medicalHistory);

private:
    std::string dateOfBirth_;
    std::string medicalHistory_;
};
