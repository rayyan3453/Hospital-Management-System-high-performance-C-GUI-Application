#pragma once

#include "models/User.h"

/**
 * @brief Doctor user with specialization and schedule details.
 */
class Doctor final : public User {
public:
    /**
     * @brief Constructs a doctor user.
     * @param id User identifier.
     * @param name Full name.
     * @param email Email address.
     * @param passwordHash Hashed password.
     * @param specialization Doctor specialization.
     * @param schedule Weekly schedule descriptor.
     */
    Doctor(std::string id,
           std::string name,
           std::string email,
           std::string passwordHash,
           std::string specialization,
           std::string schedule);

    /**
     * @brief Displays doctor details.
     * @return Display text.
     */
    std::string display() const override;

    /**
     * @brief Returns role.
     * @return UserRole::Doctor.
     */
    UserRole getRole() const override;

    /**
     * @brief Gets specialization.
     * @return Specialization text.
     */
    const std::string& getSpecialization() const;

    /**
     * @brief Gets schedule.
     * @return Schedule text.
     */
    const std::string& getSchedule() const;

    /**
     * @brief Sets specialization.
     * @param specialization Updated specialization.
     */
    void setSpecialization(const std::string& specialization);

    /**
     * @brief Sets schedule.
     * @param schedule Updated schedule.
     */
    void setSchedule(const std::string& schedule);

private:
    std::string specialization_;
    std::string schedule_;
};
