#pragma once

#include <string>

/**
 * @brief Represents supported user roles in the HMS.
 */
enum class UserRole {
    Admin,
    Doctor,
    Patient
};

/**
 * @brief Converts a user role to display string.
 * @param role Role enum value.
 * @return Readable role name.
 */
std::string toString(UserRole role);

/**
 * @brief Abstract base class for all users in the system.
 */
class User {
public:
    /**
     * @brief Constructs a user base object.
     * @param id User identifier.
     * @param name Full name.
     * @param email Email address.
     * @param passwordHash Hashed password.
     * @param role User role.
     */
    User(std::string id, std::string name, std::string email, std::string passwordHash, UserRole role);

    virtual ~User() = default;

    /**
     * @brief Displays user details as a string.
     * @return User details string.
     */
    virtual std::string display() const = 0;

    /**
     * @brief Gets user role.
     * @return Role enum.
     */
    virtual UserRole getRole() const = 0;

    /**
     * @brief Gets user ID.
     * @return User ID.
     */
    const std::string& getId() const;

    /**
     * @brief Gets user name.
     * @return User name.
     */
    const std::string& getName() const;

    /**
     * @brief Gets user email.
     * @return User email.
     */
    const std::string& getEmail() const;

    /**
     * @brief Gets password hash.
     * @return Password hash.
     */
    const std::string& getPasswordHash() const;

    /**
     * @brief Sets user name.
     * @param name Updated name.
     */
    void setName(const std::string& name);

    /**
     * @brief Sets user email.
     * @param email Updated email.
     */
    void setEmail(const std::string& email);

    /**
     * @brief Sets password hash.
     * @param passwordHash Updated hash.
     */
    void setPasswordHash(const std::string& passwordHash);

protected:
    /**
     * @brief Returns the stored role field to derived classes.
     * @return Internal role value.
     */
    UserRole getStoredRole() const;

private:
    std::string id_;
    std::string name_;
    std::string email_;
    std::string passwordHash_;
    UserRole role_;
};
