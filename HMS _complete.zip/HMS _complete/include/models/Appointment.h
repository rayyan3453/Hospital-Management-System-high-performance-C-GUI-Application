#pragma once

#include <string>

/**
 * @brief Appointment status values.
 */
enum class AppointmentStatus {
    Pending,
    Accepted,
    Cancelled,
    Completed
};

/**
 * @brief Converts appointment status to display string.
 * @param status Status enum value.
 * @return Readable status text.
 */
std::string toString(AppointmentStatus status);

/**
 * @brief Appointment entity linking patient and doctor.
 */
class Appointment {
public:
    /**
     * @brief Constructs an appointment.
     * @param id Appointment identifier.
     * @param patientId Patient identifier.
     * @param doctorId Doctor identifier.
     * @param dateTime Date-time string.
     * @param status Appointment status.
     * @param notes Appointment notes.
     */
    Appointment(std::string id,
                std::string patientId,
                std::string doctorId,
                std::string dateTime,
                AppointmentStatus status,
                std::string notes);

    /**
     * @brief Gets appointment ID.
     * @return Appointment ID.
     */
    const std::string& getId() const;

    /**
     * @brief Gets patient ID.
     * @return Patient ID.
     */
    const std::string& getPatientId() const;

    /**
     * @brief Gets doctor ID.
     * @return Doctor ID.
     */
    const std::string& getDoctorId() const;

    /**
     * @brief Gets appointment date-time.
     * @return Date-time string.
     */
    const std::string& getDateTime() const;

    /**
     * @brief Gets status.
     * @return Appointment status.
     */
    AppointmentStatus getStatus() const;

    /**
     * @brief Gets notes.
     * @return Notes text.
     */
    const std::string& getNotes() const;

    /**
     * @brief Sets date-time.
     * @param dateTime Updated date-time string.
     */
    void setDateTime(const std::string& dateTime);

    /**
     * @brief Sets status.
     * @param status Updated status.
     */
    void setStatus(AppointmentStatus status);

    /**
     * @brief Sets notes.
     * @param notes Updated notes.
     */
    void setNotes(const std::string& notes);

private:
    std::string id_;
    std::string patientId_;
    std::string doctorId_;
    std::string dateTime_;
    AppointmentStatus status_;
    std::string notes_;
};
