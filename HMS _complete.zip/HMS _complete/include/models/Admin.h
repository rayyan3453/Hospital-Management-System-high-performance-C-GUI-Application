#pragma once

#include "models/User.h"

/**
 * @brief Admin user with full management privileges.
 */
class Admin final : public User {
public:
    /**
     * @brief Constructs an admin user.
     * @param id User identifier.
     * @param name Full name.
     * @param email Email address.
     * @param passwordHash Hashed password.
     */
    Admin(std::string id, std::string name, std::string email, std::string passwordHash);

    /**
     * @brief Displays admin details.
     * @return Display text.
     */
    std::string display() const override;

    /**
     * @brief Returns role.
     * @return UserRole::Admin.
     */
    UserRole getRole() const override;
};
