#pragma once

#include <string>

/**
 * @brief Medical record entry created by a doctor for a patient.
 */
class MedicalRecord {
public:
    /**
     * @brief Constructs a medical record.
     * @param id Record identifier.
     * @param patientId Patient identifier.
     * @param doctorId Doctor identifier.
     * @param diagnosis Diagnosis text.
     * @param prescription Prescription text.
     * @param date Record date.
     */
    MedicalRecord(std::string id,
                  std::string patientId,
                  std::string doctorId,
                  std::string diagnosis,
                  std::string prescription,
                  std::string date);

    /**
     * @brief Gets record ID.
     * @return Record ID.
     */
    const std::string& getId() const;

    /**
     * @brief Gets patient ID.
     * @return Patient ID.
     */
    const std::string& getPatientId() const;

    /**
     * @brief Gets doctor ID.
     * @return Doctor ID.
     */
    const std::string& getDoctorId() const;

    /**
     * @brief Gets diagnosis.
     * @return Diagnosis text.
     */
    const std::string& getDiagnosis() const;

    /**
     * @brief Gets prescription.
     * @return Prescription text.
     */
    const std::string& getPrescription() const;

    /**
     * @brief Gets date.
     * @return Date text.
     */
    const std::string& getDate() const;

    /**
     * @brief Sets diagnosis.
     * @param diagnosis Updated diagnosis text.
     */
    void setDiagnosis(const std::string& diagnosis);

    /**
     * @brief Sets prescription.
     * @param prescription Updated prescription text.
     */
    void setPrescription(const std::string& prescription);

    /**
     * @brief Sets date.
     * @param date Updated date text.
     */
    void setDate(const std::string& date);

private:
    std::string id_;
    std::string patientId_;
    std::string doctorId_;
    std::string diagnosis_;
    std::string prescription_;
    std::string date_;
};
