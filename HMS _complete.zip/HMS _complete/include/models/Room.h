#pragma once

#include <string>

/**
 * @brief Hospital room resource and occupancy state.
 */
class Room {
public:
    /**
     * @brief Constructs a room.
     * @param id Room identifier.
     * @param type Room type.
     * @param isOccupied Occupancy status.
     * @param assignedPatientId Assigned patient ID or empty.
     */
    Room(std::string id, std::string type, bool isOccupied, std::string assignedPatientId);

    /**
     * @brief Gets room ID.
     * @return Room ID.
     */
    const std::string& getId() const;

    /**
     * @brief Gets room type.
     * @return Room type.
     */
    const std::string& getType() const;

    /**
     * @brief Gets occupancy status.
     * @return True if occupied.
     */
    bool getIsOccupied() const;

    /**
     * @brief Gets assigned patient ID.
     * @return Assigned patient ID or empty.
     */
    const std::string& getAssignedPatientId() const;

    /**
     * @brief Sets room type.
     * @param type Updated room type.
     */
    void setType(const std::string& type);

    /**
     * @brief Sets occupancy status.
     * @param isOccupied Updated occupancy value.
     */
    void setIsOccupied(bool isOccupied);

    /**
     * @brief Sets assigned patient ID.
     * @param assignedPatientId Updated assigned patient ID.
     */
    void setAssignedPatientId(const std::string& assignedPatientId);

private:
    std::string id_;
    std::string type_;
    bool isOccupied_;
    std::string assignedPatientId_;
};
