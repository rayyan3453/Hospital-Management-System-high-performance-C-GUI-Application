#pragma once

#include <string>

/**
 * @brief Billing record for patient invoices.
 */
class Billing {
public:
    /**
     * @brief Constructs a billing record.
     * @param id Billing identifier.
     * @param patientId Patient identifier.
     * @param amount Total bill amount.
     * @param isPaid Payment status.
     * @param date Billing date.
     * @param itemizedList Line-item details.
     */
    Billing(std::string id,
            std::string patientId,
            double amount,
            bool isPaid,
            std::string date,
            std::string itemizedList);

    /**
     * @brief Gets bill ID.
     * @return Bill ID.
     */
    const std::string& getId() const;

    /**
     * @brief Gets patient ID.
     * @return Patient ID.
     */
    const std::string& getPatientId() const;

    /**
     * @brief Gets amount.
     * @return Bill amount.
     */
    double getAmount() const;

    /**
     * @brief Gets payment status.
     * @return True if paid.
     */
    bool getIsPaid() const;

    /**
     * @brief Gets bill date.
     * @return Date string.
     */
    const std::string& getDate() const;

    /**
     * @brief Gets itemized list.
     * @return Itemized details.
     */
    const std::string& getItemizedList() const;

    /**
     * @brief Sets amount.
     * @param amount Updated amount.
     */
    void setAmount(double amount);

    /**
     * @brief Sets payment status.
     * @param isPaid Updated status.
     */
    void setIsPaid(bool isPaid);

    /**
     * @brief Sets date.
     * @param date Updated date.
     */
    void setDate(const std::string& date);

    /**
     * @brief Sets itemized list.
     * @param itemizedList Updated line-item details.
     */
    void setItemizedList(const std::string& itemizedList);

private:
    std::string id_;
    std::string patientId_;
    double amount_;
    bool isPaid_;
    std::string date_;
    std::string itemizedList_;
};
