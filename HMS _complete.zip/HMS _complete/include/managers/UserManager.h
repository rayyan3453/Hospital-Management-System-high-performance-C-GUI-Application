#pragma once

#include "models/User.h"

#include <memory>
#include <optional>
#include <string>
#include <vector>

class Admin;
class Doctor;
class Patient;

/**
 * @brief Service for user CRUD, auth, filtering, and CSV persistence.
 */
class UserManager {
public:
    /**
     * @brief Loads users from CSV file and remembers path for autosave.
     * @param path CSV file path.
     */
    void loadFromFile(const std::string& path);

    /**
     * @brief Saves users to CSV file.
     * @param path CSV file path.
     */
    void saveToFile(const std::string& path) const;

    /**
     * @brief Sets default persistence path used for mutation autosave.
     * @param path CSV file path.
     */
    void setPersistencePath(const std::string& path);

    /**
     * @brief Returns all users as non-owning pointers.
     * @return User pointer list.
     */
    std::vector<const User*> getAllUsers() const;

    /**
     * @brief Finds user by ID.
     * @param id User ID.
     * @return User pointer if found.
     */
    std::optional<const User*> findById(const std::string& id) const;

    /**
     * @brief Finds user by email.
     * @param email User email.
     * @return User pointer if found.
     */
    std::optional<const User*> findByEmail(const std::string& email) const;

    /**
     * @brief Searches users by optional name fragment and role.
     * @param nameQuery Substring to match in name (case-insensitive).
     * @param roleFilter Role filter when provided.
     * @return Matched user pointers.
     */
    std::vector<const User*> searchUsers(const std::string& nameQuery,
                                         std::optional<UserRole> roleFilter) const;

    /**
     * @brief Authenticates by email/password hash and role.
     * @param email Email input.
     * @param plainPassword Plain password input.
     * @param role Expected role.
     * @return Matching user pointer on success.
     */
    std::optional<const User*> login(const std::string& email,
                                     const std::string& plainPassword,
                                     UserRole role) const;

    /**
     * @brief Adds an admin user.
     */
    void addAdmin(const Admin& admin);

    /**
     * @brief Adds a doctor user.
     */
    void addDoctor(const Doctor& doctor);

    /**
     * @brief Adds a patient user.
     */
    void addPatient(const Patient& patient);

    /**
     * @brief Updates common user fields.
     * @param id User ID.
     * @param name Updated name.
     * @param email Updated email.
     * @param passwordHash Updated password hash.
     * @return True when updated.
     */
    bool updateUser(const std::string& id,
                    const std::string& name,
                    const std::string& email,
                    const std::string& passwordHash);

    /**
     * @brief Updates doctor-specific fields.
     * @param id Doctor ID.
     * @param specialization Updated specialization.
     * @param schedule Updated schedule.
     * @return True when updated.
     */
    bool updateDoctorDetails(const std::string& id,
                             const std::string& specialization,
                             const std::string& schedule);

    /**
     * @brief Updates patient-specific fields.
     * @param id Patient ID.
     * @param dateOfBirth Updated birth date.
     * @param medicalHistory Updated medical history.
     * @return True when updated.
     */
    bool updatePatientDetails(const std::string& id,
                              const std::string& dateOfBirth,
                              const std::string& medicalHistory);

    /**
     * @brief Deletes user by ID.
     * @param id User ID.
     * @return True when deleted.
     */
    bool deleteUser(const std::string& id);

private:
    void autoSaveIfConfigured() const;
    bool idExists(const std::string& id) const;
    bool emailExists(const std::string& email, const std::string& excludeId = "") const;

    std::vector<std::unique_ptr<User>> users_;
    std::string persistencePath_;
};
