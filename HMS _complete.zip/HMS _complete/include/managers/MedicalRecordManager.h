#pragma once

#include "models/MedicalRecord.h"

#include <optional>
#include <string>
#include <vector>

/**
 * @brief Service for medical-record CRUD, ownership-based listing, and CSV persistence.
 */
class MedicalRecordManager {
public:
    /**
     * @brief Loads records from CSV and remembers path for autosave.
     * @param path CSV path.
     */
    void loadFromFile(const std::string& path);

    /**
     * @brief Saves records to CSV.
     * @param path CSV path.
     */
    void saveToFile(const std::string& path) const;

    /**
     * @brief Sets default persistence path used for autosave on mutation.
     * @param path CSV path.
     */
    void setPersistencePath(const std::string& path);

    /**
     * @brief Gets all records.
     * @return All records.
     */
    std::vector<MedicalRecord> getAllRecords() const;

    /**
     * @brief Finds record by ID.
     * @param id Record ID.
     * @return Matching record if found.
     */
    std::optional<MedicalRecord> findById(const std::string& id) const;

    /**
     * @brief Lists records by patient ID.
     * @param patientId Patient ID.
     * @return Matching records.
     */
    std::vector<MedicalRecord> listByPatientId(const std::string& patientId) const;

    /**
     * @brief Lists records by doctor ID.
     * @param doctorId Doctor ID.
     * @return Matching records.
     */
    std::vector<MedicalRecord> listByDoctorId(const std::string& doctorId) const;

    /**
     * @brief Adds a new record.
     * @param id Record ID.
     * @param patientId Patient ID.
     * @param doctorId Doctor ID.
     * @param diagnosis Diagnosis text.
     * @param prescription Prescription text.
     * @param date Record date YYYY-MM-DD.
     * @return True when added.
     */
    bool addRecord(const std::string& id,
                   const std::string& patientId,
                   const std::string& doctorId,
                   const std::string& diagnosis,
                   const std::string& prescription,
                   const std::string& date);

    /**
     * @brief Edits an existing record.
     * @param id Record ID.
     * @param diagnosis Updated diagnosis.
     * @param prescription Updated prescription.
     * @param date Updated date.
     * @return True when updated.
     */
    bool editRecord(const std::string& id,
                    const std::string& diagnosis,
                    const std::string& prescription,
                    const std::string& date);

private:
    void autoSaveIfConfigured() const;
    bool idExists(const std::string& id) const;

    std::vector<MedicalRecord> records_;
    std::string persistencePath_;
};
