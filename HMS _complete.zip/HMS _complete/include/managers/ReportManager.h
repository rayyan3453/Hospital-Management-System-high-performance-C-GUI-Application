#pragma once

#include "managers/AppointmentManager.h"
#include "managers/UserManager.h"

#include <string>
#include <vector>

/**
 * @brief Aggregates reporting metrics for admin dashboards and analytics.
 */
class ReportManager {
public:
    /**
     * @brief Represents appointment count for a time bucket.
     */
    struct TimeBucketStat {
        std::string label;
        int count = 0;
    };

    /**
     * @brief Snapshot of key summary metrics.
     */
    struct Summary {
        int patientCount = 0;
        int doctorCount = 0;
        int adminCount = 0;
        int totalAppointments = 0;
        int pendingAppointments = 0;
        int completedAppointments = 0;
        int cancelledAppointments = 0;
    };

    /**
     * @brief Constructs report manager over existing services.
     * @param userManager User service.
     * @param appointmentManager Appointment service.
     */
    ReportManager(const UserManager& userManager, const AppointmentManager& appointmentManager);

    /**
     * @brief Gets overall user and appointment summary.
     * @return Summary metrics.
     */
    Summary getSummary() const;

    /**
     * @brief Gets appointment counts for each day in week window.
     * @param weekStartDate Date YYYY-MM-DD.
     * @return Seven bucket stats.
     */
    std::vector<TimeBucketStat> weeklyAppointmentStats(const std::string& weekStartDate) const;

    /**
     * @brief Gets appointment counts for one day, grouped by hour.
     * @param date Date YYYY-MM-DD.
     * @return Hourly bucket stats from 00 to 23.
     */
    std::vector<TimeBucketStat> dailyAppointmentStats(const std::string& date) const;

private:
    const UserManager& userManager_;
    const AppointmentManager& appointmentManager_;
};
