#pragma once

#include "models/Billing.h"

#include <optional>
#include <string>
#include <vector>

/**
 * @brief Service for billing CRUD, payment status updates, summaries, and CSV persistence.
 */
class BillingManager {
public:
    /**
     * @brief Revenue summary for dashboard and reports.
     */
    struct Summary {
        double totalRevenue = 0.0;
        double outstandingAmount = 0.0;
    };

    /**
     * @brief Loads billing rows from CSV and remembers path for autosave.
     * @param path CSV file path.
     */
    void loadFromFile(const std::string& path);

    /**
     * @brief Saves billing rows to CSV.
     * @param path CSV file path.
     */
    void saveToFile(const std::string& path) const;

    /**
     * @brief Sets default persistence path used for autosave mutations.
     * @param path CSV file path.
     */
    void setPersistencePath(const std::string& path);

    /**
     * @brief Gets all bills.
     * @return Bill list.
     */
    std::vector<Billing> getAllBills() const;

    /**
     * @brief Finds bill by ID.
     * @param id Bill ID.
     * @return Matching bill.
     */
    std::optional<Billing> findById(const std::string& id) const;

    /**
     * @brief Lists bills by patient ID.
     * @param patientId Patient ID.
     * @return Matching bills.
     */
    std::vector<Billing> listByPatientId(const std::string& patientId) const;

    /**
     * @brief Creates a bill.
     * @param id Bill ID.
     * @param patientId Patient ID.
     * @param amount Amount.
     * @param isPaid Payment status.
     * @param date Date YYYY-MM-DD.
     * @param itemizedList Itemized text.
     * @return True when added.
     */
    bool createBill(const std::string& id,
                    const std::string& patientId,
                    double amount,
                    bool isPaid,
                    const std::string& date,
                    const std::string& itemizedList);

    /**
     * @brief Updates main bill fields.
     * @param id Bill ID.
     * @param amount Updated amount.
     * @param date Updated date.
     * @param itemizedList Updated details.
     * @return True when updated.
     */
    bool updateBill(const std::string& id,
                    double amount,
                    const std::string& date,
                    const std::string& itemizedList);

    /**
     * @brief Marks bill paid/unpaid.
     * @param id Bill ID.
     * @param isPaid New paid state.
     * @return True when updated.
     */
    bool markPaidStatus(const std::string& id, bool isPaid);

    /**
     * @brief Gets total revenue and outstanding amount.
     * @return Summary values.
     */
    Summary getSummary() const;

private:
    void autoSaveIfConfigured() const;
    bool idExists(const std::string& id) const;

    std::vector<Billing> bills_;
    std::string persistencePath_;
};
