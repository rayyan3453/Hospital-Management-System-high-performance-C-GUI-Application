#pragma once

#include "models/Appointment.h"

#include <optional>
#include <string>
#include <vector>

/**
 * @brief Service for appointment scheduling, status actions, filtering, and CSV persistence.
 */
class AppointmentManager {
public:
    /**
     * @brief Loads appointments from CSV and remembers path for autosave.
     * @param path CSV file path.
     */
    void loadFromFile(const std::string& path);

    /**
     * @brief Saves appointments to CSV.
     * @param path CSV file path.
     */
    void saveToFile(const std::string& path) const;

    /**
     * @brief Sets default persistence path used for mutation autosave.
     * @param path CSV file path.
     */
    void setPersistencePath(const std::string& path);

    /**
     * @brief Returns all appointments.
     * @return Appointment list copy.
     */
    std::vector<Appointment> getAllAppointments() const;

    /**
     * @brief Finds appointment by ID.
     * @param id Appointment ID.
     * @return Matching appointment.
     */
    std::optional<Appointment> findById(const std::string& id) const;

    /**
     * @brief Creates a new pending appointment.
     * @param id Appointment ID.
     * @param patientId Patient ID.
     * @param doctorId Doctor ID.
     * @param dateTime Date-time (YYYY-MM-DD HH:MM).
     * @param notes Optional notes.
     * @return True on success.
     */
    bool scheduleAppointment(const std::string& id,
                             const std::string& patientId,
                             const std::string& doctorId,
                             const std::string& dateTime,
                             const std::string& notes);

    /**
     * @brief Cancels appointment by ID.
     * @param id Appointment ID.
     * @return True when state changed.
     */
    bool cancelAppointment(const std::string& id);

    /**
     * @brief Reschedules appointment date-time.
     * @param id Appointment ID.
     * @param newDateTime New date-time.
     * @return True when updated.
     */
    bool rescheduleAppointment(const std::string& id, const std::string& newDateTime);

    /**
     * @brief Updates appointment status.
     * @param id Appointment ID.
     * @param status New status.
     * @return True when updated.
     */
    bool updateStatus(const std::string& id, AppointmentStatus status);

    /**
     * @brief Lists appointments using optional filters.
     * @param doctorId Optional doctor ID.
     * @param patientId Optional patient ID.
     * @param status Optional status.
     * @param startDateTime Optional inclusive range start.
     * @param endDateTime Optional inclusive range end.
     * @return Filtered list.
     */
    std::vector<Appointment> listAppointments(std::optional<std::string> doctorId,
                                              std::optional<std::string> patientId,
                                              std::optional<AppointmentStatus> status,
                                              std::optional<std::string> startDateTime,
                                              std::optional<std::string> endDateTime) const;

private:
    void autoSaveIfConfigured() const;
    bool idExists(const std::string& id) const;
    bool doctorSlotTaken(const std::string& doctorId, const std::string& dateTime, const std::string& excludeId = "") const;

    std::vector<Appointment> appointments_;
    std::string persistencePath_;
};
