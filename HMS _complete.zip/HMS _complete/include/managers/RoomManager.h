#pragma once

#include "models/Room.h"

#include <optional>
#include <string>
#include <vector>

/**
 * @brief Service for room CRUD, assignment/release logic, occupancy checks, and CSV persistence.
 */
class RoomManager {
public:
    /**
     * @brief Loads rooms from CSV and remembers path for autosave.
     * @param path CSV file path.
     */
    void loadFromFile(const std::string& path);

    /**
     * @brief Saves rooms to CSV.
     * @param path CSV file path.
     */
    void saveToFile(const std::string& path) const;

    /**
     * @brief Sets default persistence path for autosave.
     * @param path CSV file path.
     */
    void setPersistencePath(const std::string& path);

    /**
     * @brief Gets all rooms.
     * @return Room list.
     */
    std::vector<Room> getAllRooms() const;

    /**
     * @brief Finds room by ID.
     * @param id Room ID.
     * @return Matching room.
     */
    std::optional<Room> findById(const std::string& id) const;

    /**
     * @brief Lists only available rooms.
     * @return Non-occupied rooms.
     */
    std::vector<Room> listAvailableRooms() const;

    /**
     * @brief Adds a room.
     * @param id Room ID.
     * @param type Room type.
     * @return True when added.
     */
    bool addRoom(const std::string& id, const std::string& type);

    /**
     * @brief Assigns room to patient.
     * @param roomId Room ID.
     * @param patientId Patient ID.
     * @return True when assignment succeeded.
     */
    bool assignRoom(const std::string& roomId, const std::string& patientId);

    /**
     * @brief Releases room occupancy.
     * @param roomId Room ID.
     * @return True when room was occupied and released.
     */
    bool releaseRoom(const std::string& roomId);

private:
    void autoSaveIfConfigured() const;
    bool idExists(const std::string& id) const;
    bool patientAlreadyAssigned(const std::string& patientId) const;

    std::vector<Room> rooms_;
    std::string persistencePath_;
};
