#pragma once

#include "managers/AppointmentManager.h"
#include "managers/BillingManager.h"
#include "managers/MedicalRecordManager.h"
#include "managers/UserManager.h"

#include <optional>
#include <string>
#include <vector>

/**
 * @brief Patient-facing application logic for booking, records, billing, profile, and session.
 */
class PatientDashboard {
public:
    /**
     * @brief Lightweight doctor info used in booking flow.
     */
    struct DoctorOption {
        std::string id;
        std::string name;
        std::string specialization;
    };

    /**
     * @brief Profile projection for patient profile tab.
     */
    struct PatientProfile {
        std::string id;
        std::string name;
        std::string email;
        std::string dateOfBirth;
        std::string medicalHistory;
    };

    /**
     * @brief Patient-facing medical record row with attending doctor metadata.
     */
    struct MedicalHistoryEntry {
        std::string recordId;
        std::string diagnosis;
        std::string prescription;
        std::string date;
        std::string doctorId;
        std::string doctorName;
    };

    /**
     * @brief Patient-facing invoice row.
     */
    struct InvoiceEntry {
        std::string billId;
        double amount = 0.0;
        bool isPaid = false;
        std::string date;
        std::string itemizedList;
    };

    /**
     * @brief Creates dashboard logic with required managers.
     */
    PatientDashboard(UserManager& userManager,
                     AppointmentManager& appointmentManager,
                     MedicalRecordManager& medicalRecordManager,
                     BillingManager& billingManager);

    /**
     * @brief Starts patient session.
     * @param patientId Logged-in patient ID.
     * @return True when patient exists.
     */
    bool startSession(const std::string& patientId);

    /**
     * @brief Ends patient session.
     */
    void logout();

    /**
     * @brief Returns current patient ID when logged in.
     * @return Patient ID.
     */
    std::optional<std::string> currentPatientId() const;

    /**
     * @brief Gets active patient profile values.
     * @return Profile values when logged in.
     */
    std::optional<PatientProfile> myProfile() const;

    /**
     * @brief Lists available specializations from doctor profiles.
     * @return Sorted unique specialization names.
     */
    std::vector<std::string> availableSpecializations() const;

    /**
     * @brief Lists doctors matching specialization.
     * @param specialization Specialization filter.
     * @return Matching doctor options.
     */
    std::vector<DoctorOption> doctorsBySpecialization(const std::string& specialization) const;

    /**
     * @brief Computes available 30-min slots for doctor on date.
     * @param doctorId Doctor ID.
     * @param date Date YYYY-MM-DD.
     * @param startHour Day start hour.
     * @param endHour Day end hour.
     * @return Available date-time slots.
     */
    std::vector<std::string> availableSlotsForDoctor(const std::string& doctorId,
                                                     const std::string& date,
                                                     int startHour = 9,
                                                     int endHour = 17) const;

    /**
     * @brief Books appointment for active patient.
     * @param appointmentId New appointment ID.
     * @param doctorId Doctor ID.
     * @param dateTime Selected date-time.
     * @param notes Optional notes.
     * @return True on success.
     */
    bool bookAppointment(const std::string& appointmentId,
                         const std::string& doctorId,
                         const std::string& dateTime,
                         const std::string& notes);

    /**
     * @brief Gets patient appointments.
     * @param includePast Include past entries when true.
     * @return Appointment list.
     */
    std::vector<Appointment> myAppointments(bool includePast) const;

    /**
     * @brief Cancels a pending/accepted patient appointment.
     * @param appointmentId Appointment ID.
     * @return True on success.
     */
    bool cancelMyAppointment(const std::string& appointmentId);

    /**
     * @brief Reads patient's own medical history (read-only).
     * @return Medical records.
     */
    std::vector<MedicalHistoryEntry> myMedicalHistory() const;

    /**
     * @brief Reads patient's own invoices.
     * @return Billing entries.
     */
    std::vector<InvoiceEntry> myInvoices() const;

    /**
     * @brief Updates patient profile data.
     * @param name Updated name.
     * @param email Updated email.
     * @param dateOfBirth Updated DOB.
     * @param medicalHistory Updated summary.
     * @param newPlainPassword Optional new password.
     * @return True on success.
     */
    bool updateMyProfile(const std::string& name,
                         const std::string& email,
                         const std::string& dateOfBirth,
                         const std::string& medicalHistory,
                         const std::optional<std::string>& newPlainPassword);

private:
    bool isOwnedAppointment(const Appointment& appointment) const;

    UserManager& userManager_;
    AppointmentManager& appointmentManager_;
    MedicalRecordManager& medicalRecordManager_;
    BillingManager& billingManager_;
    std::optional<std::string> activePatientId_;
};
