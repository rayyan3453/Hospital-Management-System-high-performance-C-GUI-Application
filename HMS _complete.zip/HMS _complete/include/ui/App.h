#pragma once

#include "managers/AppointmentManager.h"
#include "managers/BillingManager.h"
#include "managers/MedicalRecordManager.h"
#include "managers/ReportManager.h"
#include "managers/RoomManager.h"
#include "managers/UserManager.h"
#include "ui/AdminDashboard.h"
#include "ui/DoctorDashboard.h"
#include "ui/LoginScreen.h"
#include "ui/PatientDashboard.h"

#include <memory>
#include <optional>
#include <string>
#include <array>

/**
 * @brief Root application composition and role-based routing state.
 */
class App {
public:
    /**
     * @brief Active top-level route.
     */
    enum class Route {
        Login,
        AdminDashboard,
        DoctorDashboard,
        PatientDashboard
    };

    /**
     * @brief Builds app and composes all managers/screens.
     */
    App();

    /**
     * @brief Loads all CSV data and binds persistence paths.
     * @param dataDirectory Data folder path.
     */
    void initialize(const std::string& dataDirectory);

    /**
     * @brief Opens the SFML window and runs the ImGui render loop until closed.
     */
    void run();

    /**
     * @brief Performs role-based login and routes to dashboard.
     * @return True on success.
     */
    bool login(const std::string& email, const std::string& plainPassword, UserRole role);

    /**
     * @brief Logs out current session and routes to login.
     */
    void logout();

    /**
     * @brief Returns active route.
     */
    Route currentRoute() const;

    LoginScreen& loginScreen();
    AdminDashboard& adminDashboard();
    DoctorDashboard& doctorDashboard();
    PatientDashboard& patientDashboard();

private:
    std::string dataDirectory_;
    Route route_ = Route::Login;

    UserManager userManager_;
    AppointmentManager appointmentManager_;
    MedicalRecordManager medicalRecordManager_;
    BillingManager billingManager_;
    RoomManager roomManager_;
    std::unique_ptr<ReportManager> reportManager_;

    std::unique_ptr<LoginScreen> loginScreen_;
    std::unique_ptr<AdminDashboard> adminDashboard_;
    std::unique_ptr<DoctorDashboard> doctorDashboard_;
    std::unique_ptr<PatientDashboard> patientDashboard_;
};
