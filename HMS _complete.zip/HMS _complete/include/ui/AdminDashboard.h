#pragma once

#include "managers/AppointmentManager.h"
#include "managers/BillingManager.h"
#include "managers/MedicalRecordManager.h"
#include "managers/ReportManager.h"
#include "managers/RoomManager.h"
#include "managers/UserManager.h"

#include <optional>
#include <string>
#include <vector>

/**
 * @brief Admin-facing orchestration logic for all management tabs.
 */
class AdminDashboard {
public:
    /**
     * @brief Aggregated data for admin billing tab.
     */
    struct BillingOverview {
        std::vector<Billing> allBills;
        BillingManager::Summary summary;
    };

    /**
     * @brief Creates admin dashboard service facade.
     */
    AdminDashboard(UserManager& userManager,
                   AppointmentManager& appointmentManager,
                   MedicalRecordManager& medicalRecordManager,
                   BillingManager& billingManager,
                   RoomManager& roomManager,
                   ReportManager& reportManager);

    /**
     * @brief Starts admin session.
     * @param adminId Logged-in admin ID.
     * @return True when admin exists.
     */
    bool startSession(const std::string& adminId);

    /**
     * @brief Clears current session.
     */
    void logout();

    /**
     * @brief Gets current admin ID.
     * @return Admin ID when active.
     */
    std::optional<std::string> currentAdminId() const;

    // User management
    std::vector<const User*> users(const std::string& nameQuery, std::optional<UserRole> roleFilter) const;
    bool addDoctor(const std::string& id,
                   const std::string& name,
                   const std::string& email,
                   const std::string& plainPassword,
                   const std::string& specialization,
                   const std::string& schedule);
    bool addPatient(const std::string& id,
                    const std::string& name,
                    const std::string& email,
                    const std::string& plainPassword,
                    const std::string& dateOfBirth,
                    const std::string& medicalHistory);
    bool editUser(const std::string& id, const std::string& name, const std::string& email);
    bool deleteUser(const std::string& id);

    // Room management
    std::vector<Room> rooms() const;
    bool addRoom(const std::string& id, const std::string& type);
    bool assignRoom(const std::string& roomId, const std::string& patientId);
    bool releaseRoom(const std::string& roomId);

    // Appointment overview
    std::vector<Appointment> appointments(std::optional<std::string> doctorId,
                                          std::optional<AppointmentStatus> status,
                                          std::optional<std::string> startDateTime,
                                          std::optional<std::string> endDateTime) const;
    bool cancelAppointment(const std::string& appointmentId);

    // Billing
    BillingOverview billingOverview() const;
    bool setBillPaid(const std::string& billId, bool isPaid);

    // Reports
    ReportManager::Summary reportSummary() const;
    std::vector<ReportManager::TimeBucketStat> reportDaily(const std::string& date) const;
    std::vector<ReportManager::TimeBucketStat> reportWeekly(const std::string& weekStartDate) const;

private:
    bool sessionActive() const;

    UserManager& userManager_;
    AppointmentManager& appointmentManager_;
    MedicalRecordManager& medicalRecordManager_;
    BillingManager& billingManager_;
    RoomManager& roomManager_;
    ReportManager& reportManager_;
    std::optional<std::string> activeAdminId_;
};
