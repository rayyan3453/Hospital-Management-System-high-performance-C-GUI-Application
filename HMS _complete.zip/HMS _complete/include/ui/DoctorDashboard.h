#pragma once

#include "managers/AppointmentManager.h"
#include "managers/MedicalRecordManager.h"
#include "managers/UserManager.h"

#include <optional>
#include <string>
#include <vector>

/**
 * @brief Doctor-facing application logic for appointments, records, schedule, and profile.
 */
class DoctorDashboard {
public:
    /**
     * @brief Represents one slot in weekly schedule view.
     */
    struct ScheduleSlot {
        std::string dateTime;
        bool isBooked = false;
        std::string appointmentId;
        std::string patientId;
    };

    /**
     * @brief Doctor profile projection for Profile tab view.
     */
    struct DoctorProfile {
        std::string id;
        std::string name;
        std::string email;
        std::string specialization;
        std::string schedule;
    };

    /**
     * @brief Creates dashboard logic with required managers.
     */
    DoctorDashboard(UserManager& userManager,
                    AppointmentManager& appointmentManager,
                    MedicalRecordManager& medicalRecordManager);

    /**
     * @brief Starts a doctor session.
     * @param doctorId Logged-in doctor ID.
     * @return True when doctor exists and role is doctor.
     */
    bool startSession(const std::string& doctorId);

    /**
     * @brief Ends current doctor session.
     */
    void logout();

    /**
     * @brief Gets current doctor ID if session active.
     * @return Doctor ID.
     */
    std::optional<std::string> currentDoctorId() const;

    /**
     * @brief Gets active doctor's profile values for UI display.
     * @return Profile data when session is active.
     */
    std::optional<DoctorProfile> myProfile() const;

    /**
     * @brief Returns appointments for active doctor.
     * @param includePast Include past entries when true.
     * @return Appointment list.
     */
    std::vector<Appointment> myAppointments(bool includePast) const;

    /**
     * @brief Accepts one of doctor's appointments.
     * @param appointmentId Appointment ID.
     * @return True on success.
     */
    bool acceptAppointment(const std::string& appointmentId);

    /**
     * @brief Cancels one of doctor's appointments.
     * @param appointmentId Appointment ID.
     * @return True on success.
     */
    bool cancelAppointment(const std::string& appointmentId);

    /**
     * @brief Marks one of doctor's appointments completed.
     * @param appointmentId Appointment ID.
     * @return True on success.
     */
    bool completeAppointment(const std::string& appointmentId);

    /**
     * @brief Searches the doctor's patients by patient ID or name fragment.
     * @param query ID or name fragment; empty returns all own patients.
     * @return Matched patient pointers.
     */
    std::vector<const User*> searchMyPatients(const std::string& query) const;

    /**
     * @brief Returns full patient medical history for doctor's own patient.
     * @param patientId Patient ID.
     * @return Medical records.
     */
    std::vector<MedicalRecord> patientHistory(const std::string& patientId) const;

    /**
     * @brief Adds medical record under active doctor.
     * @return True on success.
     */
    bool addMedicalRecord(const std::string& id,
                          const std::string& patientId,
                          const std::string& diagnosis,
                          const std::string& prescription,
                          const std::string& date);

    /**
     * @brief Edits doctor's own existing medical record.
     * @return True on success.
     */
    bool editMedicalRecord(const std::string& id,
                           const std::string& diagnosis,
                           const std::string& prescription,
                           const std::string& date);

    /**
     * @brief Builds one-week schedule grid from start date.
     * @param weekStartDate Start date YYYY-MM-DD.
     * @param startHour Daily start hour.
     * @param endHour Daily end hour.
     * @return Slot list for 7 days.
     */
    std::vector<ScheduleSlot> myWeeklySchedule(const std::string& weekStartDate,
                                               int startHour = 9,
                                               int endHour = 17) const;

    /**
     * @brief Updates active doctor's profile details.
     * @param name Updated name.
     * @param email Updated email.
     * @param specialization Updated specialization.
     * @param schedule Updated contact/schedule text.
     * @param newPlainPassword Optional new plain password.
     * @return True on success.
     */
    bool updateMyProfile(const std::string& name,
                         const std::string& email,
                         const std::string& specialization,
                         const std::string& schedule,
                         const std::optional<std::string>& newPlainPassword);

private:
    bool isOwnedAppointment(const Appointment& appointment) const;
    bool hasDoctorPatientRelationship(const std::string& patientId) const;

    UserManager& userManager_;
    AppointmentManager& appointmentManager_;
    MedicalRecordManager& medicalRecordManager_;
    std::optional<std::string> activeDoctorId_;
};
