#pragma once

#include "managers/UserManager.h"

#include <optional>
#include <string>

/**
 * @brief Login workflow helper for role-based authentication.
 */
class LoginScreen {
public:
    /**
     * @brief Authenticated session identity.
     */
    struct Session {
        std::string userId;
        UserRole role = UserRole::Patient;
    };

    /**
     * @brief Creates login helper over user manager.
     * @param userManager User service.
     */
    explicit LoginScreen(UserManager& userManager);

    /**
     * @brief Attempts role-bound login with email/password.
     * @param email Email input.
     * @param plainPassword Plain password input.
     * @param role Selected role.
     * @return Session on success.
     */
    std::optional<Session> login(const std::string& email,
                                 const std::string& plainPassword,
                                 UserRole role) const;

private:
    UserManager& userManager_;
};
