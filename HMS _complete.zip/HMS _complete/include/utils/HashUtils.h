#pragma once

#include <string>

namespace HashUtils {
/**
 * @brief Computes a deterministic djb2 hash string for a plain-text password.
 * @param value Plain-text input.
 * @return Decimal string representation of hashed value.
 */
std::string hashPassword(const std::string& value);

/**
 * @brief Verifies whether plain-text input matches stored hash.
 * @param plainText Plain-text password.
 * @param hashed Stored hash value.
 * @return True when hashes match.
 */
bool verifyPassword(const std::string& plainText, const std::string& hashed);
}  // namespace HashUtils
