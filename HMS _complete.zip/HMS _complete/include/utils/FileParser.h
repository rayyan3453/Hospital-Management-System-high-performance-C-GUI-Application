#pragma once

#include <string>
#include <vector>

namespace FileParser {
/**
 * @brief Parses one CSV row into columns with quote support.
 * @param line Raw CSV row.
 * @return Parsed column list.
 */
std::vector<std::string> parseCsvRow(const std::string& line);

/**
 * @brief Serializes columns into one CSV row with escaping.
 * @param fields Column values.
 * @return Escaped CSV row.
 */
std::string toCsvRow(const std::vector<std::string>& fields);

/**
 * @brief Loads an entire CSV file into rows.
 * @param path File path.
 * @return Vector of rows where each row is a vector of fields.
 */
std::vector<std::vector<std::string>> readCsvFile(const std::string& path);

/**
 * @brief Writes all rows to CSV file (overwrites target).
 * @param path File path.
 * @param rows Table rows.
 */
void writeCsvFile(const std::string& path, const std::vector<std::vector<std::string>>& rows);
}  // namespace FileParser
