#pragma once

#include <optional>
#include <string>
#include <vector>

namespace DateUtils {
/**
 * @brief Validates date format YYYY-MM-DD.
 * @param value Date string.
 * @return True if format and range are valid.
 */
bool isValidDate(const std::string& value);

/**
 * @brief Validates date-time format YYYY-MM-DD HH:MM.
 * @param value Date-time string.
 * @return True if format and range are valid.
 */
bool isValidDateTime(const std::string& value);

/**
 * @brief Compares two date-time strings.
 * @param lhs Left date-time in YYYY-MM-DD HH:MM.
 * @param rhs Right date-time in YYYY-MM-DD HH:MM.
 * @return -1 if lhs<rhs, 0 if equal, 1 if lhs>rhs.
 */
int compareDateTime(const std::string& lhs, const std::string& rhs);

/**
 * @brief Checks whether target lies in inclusive date-time range.
 * @param target Date-time to test.
 * @param start Range start.
 * @param end Range end.
 * @return True when start <= target <= end.
 */
bool isDateTimeInRange(const std::string& target, const std::string& start, const std::string& end);

/**
 * @brief Produces default 30-minute slots for one day.
 * @param date Date in YYYY-MM-DD.
 * @param startHour Day start hour (24h).
 * @param endHour Day end hour (24h, exclusive).
 * @return Slot list in YYYY-MM-DD HH:MM format.
 */
std::vector<std::string> generateDaySlots(const std::string& date, int startHour = 9, int endHour = 17);

/**
 * @brief Adds days to a date string.
 * @param date Date in YYYY-MM-DD.
 * @param days Positive or negative day offset.
 * @return Updated date string, or empty optional when input invalid.
 */
std::optional<std::string> addDays(const std::string& date, int days);

/**
 * @brief Gets local current date-time in YYYY-MM-DD HH:MM format.
 * @return Current local date-time string.
 */
std::string currentDateTime();
}  // namespace DateUtils
