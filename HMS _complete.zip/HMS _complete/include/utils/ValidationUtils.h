#pragma once

#include <string>

namespace ValidationUtils {
/**
 * @brief Returns true when value is not blank after trimming.
 * @param value Input string.
 * @return True if not empty.
 */
bool isRequiredFilled(const std::string& value);

/**
 * @brief Basic email format validation.
 * @param email Email text.
 * @return True if email looks valid.
 */
bool isValidEmail(const std::string& email);

/**
 * @brief Checks minimum password length requirement.
 * @param password Plain password.
 * @param minLength Minimum required length.
 * @return True when accepted.
 */
bool isStrongEnoughPassword(const std::string& password, int minLength = 8);

/**
 * @brief Validates simple identifier token format.
 * @param id Identifier.
 * @return True for [A-Za-z0-9_-]+.
 */
bool isValidId(const std::string& id);
}  // namespace ValidationUtils
