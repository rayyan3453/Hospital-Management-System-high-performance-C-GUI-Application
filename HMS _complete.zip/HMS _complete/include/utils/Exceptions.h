#pragma once

#include <stdexcept>
#include <string>

/**
 * @brief Exception thrown for authentication and authorization failures.
 */
class AuthException final : public std::runtime_error {
public:
    /**
     * @brief Constructs authentication exception.
     * @param message Error description.
     */
    explicit AuthException(const std::string& message);
};

/**
 * @brief Exception thrown when an entity cannot be found.
 */
class NotFoundException final : public std::runtime_error {
public:
    /**
     * @brief Constructs not-found exception.
     * @param message Error description.
     */
    explicit NotFoundException(const std::string& message);
};
