# HMS Architecture

## Layered Design

The codebase follows a strict layered architecture:

1. **Models (`include/models`, `src/models`)**
   - Pure domain entities (`User`, `Appointment`, `Billing`, etc.)
   - No persistence or UI logic
   - Encapsulated state + const-correct accessors

2. **Utilities (`include/utils`, `src/utils`)**
   - Cross-cutting helpers:
     - hashing (`HashUtils`)
     - CSV parsing (`FileParser`)
     - date-time logic (`DateUtils`)
     - validation (`ValidationUtils`)
     - domain exceptions (`AuthException`, `NotFoundException`)

3. **Managers / Services (`include/managers`, `src/managers`)**
   - Business logic and persistence boundary
   - Owns CRUD, filtering, state transitions, summary calculations
   - Handles CSV `loadFromFile()` / `saveToFile()`
   - Enforces “save after mutation” behavior

4. **Dashboard Logic (`include/ui`, `src/ui`)**
   - Role-centric orchestration for workflow actions
   - `DoctorDashboard` and `PatientDashboard` are UI-ready controllers
   - No direct file I/O in dashboard classes; manager-only interactions

5. **Application Entry (`src/main.cpp`)**
   - Runtime bootstrap and QA execution mode (`--phase11-check`)

## Core OOP Mapping

- **Inheritance / Polymorphism**
  - `User` is abstract; `Admin`, `Doctor`, `Patient` derive from it.
  - Users are stored in `UserManager` as `std::vector<std::unique_ptr<User>>`.
- **Encapsulation**
  - Entity fields are private with explicit getters/setters.
- **Composition**
  - Dashboards compose service dependencies via constructor injection.
- **Exception Handling**
  - Custom exception types exist in utility layer for auth/not-found scenarios.

## Service Responsibilities

- **`UserManager`**
  - User CRUD for all roles
  - Login/auth verification (with hash comparison)
  - Search/filter by role and name

- **`AppointmentManager`**
  - Schedule/cancel/reschedule and status transitions
  - Conflict checks for doctor slots
  - Date/status filtering for role views and reporting

- **`MedicalRecordManager`**
  - Record create/edit/list by patient or doctor
  - Used by doctor and patient workflows

- **`BillingManager`**
  - Bill create/update
  - Paid/unpaid state toggles
  - Revenue/outstanding summary

- **`RoomManager`**
  - Room add/list/assign/release
  - Occupancy and patient-assignment constraints

- **`ReportManager`**
  - Dashboard-ready summary counters
  - Daily/weekly appointment time-bucket stats

## Data Flow

1. Managers load from CSV on startup.
2. Dashboard action invokes manager method.
3. Manager mutates in-memory state.
4. Manager auto-saves to bound persistence path.
5. UI/dashboard fetches updated projections for rendering.

## Boundaries and Rules

- UI/dashboard classes do not implement persistence directly.
- Models remain independent of CSV and dashboard concerns.
- Managers are the only boundary where data serialization/deserialization occurs.
